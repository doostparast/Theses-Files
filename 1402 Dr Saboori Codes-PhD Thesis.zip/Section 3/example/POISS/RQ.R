rm(list=ls(all=TRUE))
library(gtools)
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib

y=cbind(y1,y2,y8)
n=nrow(y)

############################################


par_f=scan()
0.2117811     0.06922322     0.0159431     0.0003191458     0
0     0    0    0
0.1239411   0.08775089     0.03239269     0.003761155    0
0     0.0003888123     0     0
0.04310995     0.03682622  0.01604403     0.0004724679     0
0     0    0    0
2.64571407 2.36406714 2.37663478

par_ci=scan()
0.1807151548 0.0000000049 0.0000000441 1.7722305428 1.0522482650
1.5038601210

par_cii=scan()
0.0904744721 0.0000000022 0.0460434918 1.5539227291 0.9964353937
1.3563795964

par_ciii=scan()
0.0184890295 0.0000000152 0.0010277737 1.4165512790 0.8803388072
1.2399275875

par_c=scan()
0.1928368016 0.0006411716 0.0004786492 0.1182953209 0.0000000618
0.0656289096 0.0452784653 0.0000002261 0.0151486890 2.1837690520
1.5269762608 1.9846871191

par_p=scan()
0.19687379 0.08197660 0.03614456 0.11678022 0.01814815 0.04263219
0.04753442 0.02503701 0.06822763 2.64571407 2.36406714 2.37663478



############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}
#####################################
##########################CI
  mzkip_CI <- function(y) {
     ww=(1-(par_ci[1]+par_ci[2]+par_ci[3]))
     if((is.matrix(y))) 
     {
      nn=nrow(y)
      d=rep(0,nn)
      for(i in 1:nn)
      {
       if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_ci[1]
       else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_ci[2]
       else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_ci[3]
       d[i]=ww * fmp(y[i,],c(par_ci[4],par_ci[5],par_ci[6]))+d[i]
      }
     }
     else{
       d=0
       if((y[1]==0)&(y[2]==0)&(y[3]==0)) d=par_ci[1]
       else if((y[1]==1)&(y[2]==1)&(y[3]==1)) d=par_ci[2]
       else if((y[1]==2)&(y[2]==2)&(y[3]==2)) d=par_ci[3]
       d=ww * fmp(y,c(par_ci[4],par_ci[5],par_ci[6]))+d
     }
     d
    }
##############################
cdf_CI=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_CI(yy2))
  }
}
 return(cdf1)
}

##########################CII
  mzkip_CII <- function(y) {
     ww=(1-(par_cii[1]+par_cii[2]+par_cii[3]))
     if((is.matrix(y))) 
     {
      nn=nrow(y)
      d=rep(0,nn)
      for(i in 1:nn)
      {
       if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_cii[1]
       else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_cii[2]
       else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_cii[3]
       d[i]=ww * fmp(y[i,],c(par_cii[4],par_cii[5],par_cii[6]))+d[i]
      }
     }
     else{
       d=0
       if((y[1]==1)&(y[2]==0)&(y[3]==0)) d=par_cii[1]
       else if((y[1]==0)&(y[2]==1)&(y[3]==0)) d=par_cii[2]
       else if((y[1]==0)&(y[2]==0)&(y[3]==1)) d=par_cii[3]
       d=ww * fmp(y,c(par_cii[4],par_cii[5],par_cii[6]))+d
     }
     d
    }
##############################
cdf_CII=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_CII(yy2))
  }
}
 return(cdf1)
}

##########################CIII
  mzkip_CIII <- function(y) {
     ww=(1-(par_ciii[1]+par_ciii[2]+par_ciii[3]))
     if((is.matrix(y))) 
     {
      nn=nrow(y)
      d=rep(0,nn)
      for(i in 1:nn)
      {
       if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_ciii[1]
       else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_ciii[2]
       else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_ciii[3]
       d[i]=ww * fmp(y[i,],c(par_cii[4],par_cii[5],par_ciii[6]))+d[i]
      }
     }
     else{
       d=0
       if((y[1]==2)&(y[2]==0)&(y[3]==0)) d=par_ciii[1]
       else if((y[1]==0)&(y[2]==2)&(y[3]==0)) d=par_ciii[2]
       else if((y[1]==0)&(y[2]==0)&(y[3]==2)) d=par_ciii[3]
       d=ww * fmp(y,c(par_ciii[4],par_ciii[5],par_ciii[6]))+d
     }
     d
    }
##############################
cdf_CIII=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_CIII(yy2))
  }
}
 return(cdf1)
}

##########################C
  mzkip_C <- function(y) {
     ww=(1-(sum(par_c[1:9])))
     if((is.matrix(y)))
     {
     nn=nrow(y)
     d=rep(0,nn)
     for(i in 1:nn)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_c[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_c[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[4]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_c[5]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_c[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[7]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_c[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_c[9]
      d[i]=ww * fmp(y[i,],c(par_c[10],par_c[11],par_c[12]))+d[i]
      }
     }
     else
     {
      d=0
      if((y[1]==0)&(y[2]==0)&(y[3]==0)) d=par_c[1]
      else if((y[1]==1)&(y[2]==1)&(y[3]==1)) d=par_c[2]
      else if((y[1]==2)&(y[2]==2)&(y[3]==2)) d=par_c[3]
      else if((y[1]==1)&(y[2]==0)&(y[3]==0)) d=par_c[4]
      else if((y[1]==0)&(y[2]==1)&(y[3]==0)) d=par_c[5]
      else if((y[1]==0)&(y[2]==0)&(y[3]==1)) d=par_c[6]
      else if((y[1]==2)&(y[2]==0)&(y[3]==0)) d=par_c[7]
      else if((y[1]==0)&(y[2]==2)&(y[3]==0)) d=par_c[8]
      else if((y[1]==0)&(y[2]==0)&(y[3]==2)) d=par_c[9]
      d=ww * fmp(y,c(par_c[10],par_c[11],par_c[12]))+d
     }
     d
    }

##############################
cdf_C=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_C(yy2))
  }
}
 return(cdf1)
}

########################## FULL
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
mzkip_full <- function(y) {
     ww=(1-(sum(par_f[1:27])))
     if((is.matrix(y)))
     {
     nn=nrow(y)
     d=rep(0,nn)
     for(i in 1:nn)
      {
       if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_f[1]
       else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_f[2]
       else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_f[3]
       else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_f[4]
       else if((y[i,1]==yy[5,1])&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_f[5]
       else if((y[i,1]==yy[6,1])&(y[i,2]==1)&(y[i,3]==2)) d[i]=par_f[6]
       else if((y[i,1]==yy[7,1])&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_f[7]
       else if((y[i,1]==yy[8,1])&(y[i,2]==2)&(y[i,3]==1)) d[i]=par_f[8]
       else if((y[i,1]==yy[9,1])&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_f[9]
       else if((y[i,1]==yy[10,1])&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_f[10]
       else if((y[i,1]==yy[11,1])&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_f[11]
       else if((y[i,1]==yy[12,1])&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_f[12]
       else if((y[i,1]==yy[13,1])&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_f[13]
       else if((y[i,1]==yy[14,1])&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_f[14]
       else if((y[i,1]==yy[15,1])&(y[i,2]==1)&(y[i,3]==2)) d[i]=par_f[15]
       else if((y[i,1]==yy[16,1])&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_f[16]
       else if((y[i,1]==yy[17,1])&(y[i,2]==2)&(y[i,3]==1)) d[i]=par_f[17]
       else if((y[i,1]==yy[18,1])&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_f[18]
       else if((y[i,1]==yy[19,1])&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_f[19]
       else if((y[i,1]==yy[20,1])&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_f[20]
       else if((y[i,1]==yy[21,1])&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_f[21]
       else if((y[i,1]==yy[22,1])&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_f[22]
       else if((y[i,1]==yy[23,1])&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_f[23]
       else if((y[i,1]==yy[24,1])&(y[i,2]==1)&(y[i,3]==2)) d[i]=par_f[24]
       else if((y[i,1]==yy[25,1])&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_f[25]
       else if((y[i,1]==yy[26,1])&(y[i,2]==2)&(y[i,3]==1)) d[i]=par_f[26]
       else if((y[i,1]==yy[27,1])&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_f[27]
       d[i]=ww * fmp(y[i,],c(par_f[28],par_f[29],par_f[30]))+d[i]
      }
     }
     else
     {
      d=0
      if((y[1]==0)&(y[2]==0)&(y[3]==0)) d=par_f[1]
       else if((y[1]==0)&(y[2]==0)&(y[3]==1)) d=par_f[2]
       else if((y[1]==0)&(y[2]==0)&(y[3]==2)) d=par_f[3]
       else if((y[1]==0)&(y[2]==1)&(y[3]==0)) d=par_f[4]
       else if((y[1]==yy[5,1])&(y[2]==1)&(y[3]==1)) d=par_f[5]
       else if((y[1]==yy[6,1])&(y[2]==1)&(y[3]==2)) d=par_f[6]
       else if((y[1]==yy[7,1])&(y[2]==2)&(y[3]==0)) d=par_f[7]
       else if((y[1]==yy[8,1])&(y[2]==2)&(y[3]==1)) d=par_f[8]
       else if((y[1]==yy[9,1])&(y[2]==2)&(y[3]==2)) d=par_f[9]
       else if((y[1]==yy[10,1])&(y[2]==0)&(y[3]==0)) d=par_f[10]
       else if((y[1]==yy[11,1])&(y[2]==0)&(y[3]==1)) d=par_f[11]
       else if((y[1]==yy[12,1])&(y[2]==0)&(y[3]==2)) d=par_f[12]
       else if((y[1]==yy[13,1])&(y[2]==1)&(y[3]==0)) d=par_f[13]
       else if((y[1]==yy[14,1])&(y[2]==1)&(y[3]==1)) d=par_f[14]
       else if((y[1]==yy[15,1])&(y[2]==1)&(y[3]==2)) d=par_f[15]
       else if((y[1]==yy[16,1])&(y[2]==2)&(y[3]==0)) d=par_f[16]
       else if((y[1]==yy[17,1])&(y[2]==2)&(y[3]==1)) d=par_f[17]
       else if((y[1]==yy[18,1])&(y[2]==2)&(y[3]==2)) d=par_f[18]
       else if((y[1]==yy[19,1])&(y[2]==0)&(y[3]==0)) d=par_f[19]
       else if((y[1]==yy[20,1])&(y[2]==0)&(y[3]==1)) d=par_f[20]
       else if((y[1]==yy[21,1])&(y[2]==0)&(y[3]==2)) d=par_f[21]
       else if((y[1]==yy[22,1])&(y[2]==1)&(y[3]==0)) d=par_f[22]
       else if((y[1]==yy[23,1])&(y[2]==1)&(y[3]==1)) d=par_f[23]
       else if((y[1]==yy[24,1])&(y[2]==1)&(y[3]==2)) d=par_f[24]
       else if((y[1]==yy[25,1])&(y[2]==2)&(y[3]==0)) d=par_f[25]
       else if((y[1]==yy[26,1])&(y[2]==2)&(y[3]==1)) d=par_f[26]
       else if((y[1]==yy[27,1])&(y[2]==2)&(y[3]==2)) d=par_f[27]
       d=ww * fmp(y,c(par_f[28],par_f[29],par_f[30]))+d

     }
     d
    }

##########################
cdf_full=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_full(yy2))
  }
}
 return(cdf1)
}

##########################PROPOSED MODEL
  mzkip_P <- function(y) {
     ww=(1-(sum(par_c[1:9])))
     if((is.matrix(y)))
     {
     nn=nrow(y)
     d=rep(0,nn)
     for(i in 1:nn)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[1]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_c[2]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_c[4]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_c[5]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_c[7]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_c[8]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_c[9]
      d[i]=ww * fmp(y[i,],c(par_c[10],par_c[11],par_c[12]))+d[i]
      }
     }
     else
     {
      d=0
      if((y[1]==0)&(y[2]==0)&(y[3]==0)) d=par_c[1]
      else if((y[1]==0)&(y[2]==0)&(y[3]==1)) d=par_c[2]
      else if((y[1]==2)&(y[2]==0)&(y[3]==0)) d=par_c[3]
      else if((y[1]==1)&(y[2]==0)&(y[3]==1)) d=par_c[4]
      else if((y[1]==1)&(y[2]==0)&(y[3]==2)) d=par_c[5]
      else if((y[1]==1)&(y[2]==0)&(y[3]==0)) d=par_c[6]
      else if((y[1]==2)&(y[2]==0)&(y[3]==1)) d=par_c[7]
      else if((y[1]==0)&(y[2]==0)&(y[3]==2)) d=par_c[8]
      else if((y[1]==2)&(y[2]==0)&(y[3]==2)) d=par_c[9]
      d=ww * fmp(y,c(par_c[10],par_c[11],par_c[12]))+d
     }
     d
    }
#################################
cdfP=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_P(yy2))
  }
}
 return(cdf1)
}

##########################POISSON
  mzkip_poiss <- function(y) {
     if((is.matrix(y)))
     {
      nn=nrow(y)
      d=rep(0,nn)
      for(i in 1:nn)
       {
       d[i]= fmp(y[i,],c(mean(y1),mean(y1),mean(y1)))
       }
      }
      else
      {
       d=0
       d= fmp(y,c(mean(y1),mean(y1),mean(y1)))
      }
     d
    }
##################################
cdf_poiss=function(y){
 nnn=nrow(y)
 cdf1=rep(0,nnn)
 for(i in 1:(nnn)){
 ind=c()
 j1=0
 k=min(y[i,1],y[i,2],y[i,3])
if(k>=0){
  x=0:k
  m=3
  yy1=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
  n1=nrow(yy1)
  for(i1 in 1:n1)
   {
   if((yy1[i1,1]<=y[i,1])&(yy1[i1,2]<=y[i,2])&(yy1[i1,3]<=y[i,3])) 
    {
     j1=j1+1
     ind[j1]=i1
    }
   }
   yy2=matrix(0,j1,3)
   yy2=yy1[c(ind),]
   cdf1[i]=sum(mzkip_poiss(yy2))
  }
}
 return(cdf1)
}

#########################################################################
#########################################################################
rq_P=cdfP(y-1)+ mzkip_P(y) * runif(n)
plot(qnorm(rq_P),xlab="Observation Number",ylab="Randomized Quantile")

rq_CI=cdf_CI(y-1)+ mzkip_CI(y) * runif(n)
plot(qnorm(rq_CI),xlab="Observation Number",ylab="Randomized Quantile")

rq_CII=cdf_CII(y-1)+ mzkip_CII(y) * runif(n)
plot(qnorm(rq_CII),xlab="Observation Number",ylab="Randomized Quantile")

rq_CIII=cdf_CIII(y-1)+ mzkip_CIII(y) * runif(n)
plot(qnorm(rq_CIII),xlab="Observation Number",ylab="Randomized Quantile")

rq_C=cdf_C(y-1)+ mzkip_C(y) * runif(n)
plot(qnorm(rq_C),xlab="Observation Number",ylab="Randomized Quantile")

rq_full=cdf_full(y-1)+ mzkip_full(y) * runif(n)
plot(qnorm(rq_full),xlab="Observation Number",ylab="Randomized Quantile")

rq_poiss=cdf_poiss(y-1)+ mzkip_poiss(y) * runif(n)
plot(qnorm(rq_poiss),xlab="Observation Number",ylab="Randomized Quantile")


hist(rq_P,xlab="p-value",main="Randomized Quantile")
hist(rq_CI,xlab="p-value",main="Randomized Quantile")
hist(rq_CII,xlab="p-value",main="Randomized Quantile")
hist(rq_CIII,xlab="p-value",main="Randomized Quantile")
hist(rq_C,xlab="p-value",main="Randomized Quantile")
hist(rq_full,xlab="p-value",main="Randomized Quantile")
hist(rq_poiss,xlab="p-value",main="Randomized Quantile")


qqnorm(qnorm(rq_P),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_P),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq_CI),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_CI),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq_CII),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_CII),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq_CIII),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_CIII),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq_C),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_C),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq_full),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_full),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq_poiss),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq_poiss),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

#################################################################################
###############################################################################

library(mltools)
library(data.table)

# set data in a data.table
yt <- data.table(x = y1, y = y2, z = y3)
ecdf_P=c()
for(i in 1:n){
 ecdf_P[i]=empirical_cdf(dt, data.table(x=y[i,1],y=y[i,2],z=y[i,3]))$CDF
}
max(abs(ecdf_P-cdfP))



