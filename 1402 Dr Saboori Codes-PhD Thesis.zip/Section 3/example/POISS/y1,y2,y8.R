rm(list=ls(all=TRUE))
library(gtools)
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib

y=cbind(y1,y2,y8)
n=nrow(y)
############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}

############################################ MLE
################################################

########################################### Case I
 oute_CI_par=matrix(0,1,6)

  lmzkip_CI <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
     out_CI=constrOptim(init, lmzkip_CI, NULL, ui=u_i, ci=c_i)

########################################### Case II
 oute_CII_par=matrix(0,1,6)

  lmzkip_CII <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
     out_CII=constrOptim(init, lmzkip_CII, NULL, ui=u_i, ci=c_i)


########################################### Case III
 oute_CIII_par=matrix(0,1,6)

  lmzkip_CIII <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
     out_CIII=constrOptim(init, lmzkip_CIII, NULL, ui=u_i, ci=c_i)

##################### Case: full model
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)

 oute_full_par=matrix(0,1,30)

  lmzkip_full <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:27])))
     for(i in 1:n)
     {
      if((y[i,1]==yy[1,1])&(y[i,2]==yy[1,2])&(y[i,3]==yy[1,3])) d[i]=par[1]
      else if((y[i,1]==yy[2,1])&(y[i,2]==yy[2,2])&(y[i,3]==yy[2,3])) d[i]=par[2]
      else if((y[i,1]==yy[3,1])&(y[i,2]==yy[3,2])&(y[i,3]==yy[3,3])) d[i]=par[3]
      else if((y[i,1]==yy[4,1])&(y[i,2]==yy[4,2])&(y[i,3]==yy[4,3])) d[i]=par[4]
      else if((y[i,1]==yy[5,1])&(y[i,2]==yy[5,2])&(y[i,3]==yy[5,3])) d[i]=par[5]
      else if((y[i,1]==yy[6,1])&(y[i,2]==yy[6,2])&(y[i,3]==yy[6,3])) d[i]=par[6]
      else if((y[i,1]==yy[7,1])&(y[i,2]==yy[7,2])&(y[i,3]==yy[7,3])) d[i]=par[7]
      else if((y[i,1]==yy[8,1])&(y[i,2]==yy[8,2])&(y[i,3]==yy[8,3])) d[i]=par[8]
      else if((y[i,1]==yy[9,1])&(y[i,2]==yy[9,2])&(y[i,3]==yy[9,3])) d[i]=par[9]
      else if((y[i,1]==yy[10,1])&(y[i,2]==yy[10,2])&(y[i,3]==yy[10,3])) d[i]=par[10]
      else if((y[i,1]==yy[11,1])&(y[i,2]==yy[11,2])&(y[i,3]==yy[11,3])) d[i]=par[11]
      else if((y[i,1]==yy[12,1])&(y[i,2]==yy[12,2])&(y[i,3]==yy[12,3])) d[i]=par[12]
      else if((y[i,1]==yy[13,1])&(y[i,2]==yy[13,2])&(y[i,3]==yy[13,3])) d[i]=par[13]
      else if((y[i,1]==yy[14,1])&(y[i,2]==yy[14,2])&(y[i,3]==yy[14,3])) d[i]=par[14]
      else if((y[i,1]==yy[15,1])&(y[i,2]==yy[15,2])&(y[i,3]==yy[15,3])) d[i]=par[15]
      else if((y[i,1]==yy[16,1])&(y[i,2]==yy[16,2])&(y[i,3]==yy[16,3])) d[i]=par[16]
      else if((y[i,1]==yy[17,1])&(y[i,2]==yy[17,2])&(y[i,3]==yy[17,3])) d[i]=par[17]
      else if((y[i,1]==yy[18,1])&(y[i,2]==yy[18,2])&(y[i,3]==yy[18,3])) d[i]=par[18]
      else if((y[i,1]==yy[19,1])&(y[i,2]==yy[19,2])&(y[i,3]==yy[19,3])) d[i]=par[19]
      else if((y[i,1]==yy[20,1])&(y[i,2]==yy[20,2])&(y[i,3]==yy[20,3])) d[i]=par[20]
      else if((y[i,1]==yy[21,1])&(y[i,2]==yy[21,2])&(y[i,3]==yy[21,3])) d[i]=par[21]
      else if((y[i,1]==yy[22,1])&(y[i,2]==yy[22,2])&(y[i,3]==yy[22,3])) d[i]=par[22]
      else if((y[i,1]==yy[23,1])&(y[i,2]==yy[23,2])&(y[i,3]==yy[23,3])) d[i]=par[23]
      else if((y[i,1]==yy[24,1])&(y[i,2]==yy[24,2])&(y[i,3]==yy[24,3])) d[i]=par[24]
      else if((y[i,1]==yy[25,1])&(y[i,2]==yy[25,2])&(y[i,3]==yy[25,3])) d[i]=par[25]
      else if((y[i,1]==yy[26,1])&(y[i,2]==yy[26,2])&(y[i,3]==yy[26,3])) d[i]=par[26]
      else if((y[i,1]==yy[27,1])&(y[i,2]==yy[27,2])&(y[i,3]==yy[27,3])) d[i]=par[27]
      d[i]=ww * fmp(y[i,],c(par[28],par[29],par[30]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),
c(1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.02,nn),c(.01,.01,.01))
     out_full=constrOptim(init, lmzkip_full, NULL, ui=u_i, ci=c_i)

########################################### Case I, II, III
 oute_C_par=matrix(0,1,12)

  lmzkip_C <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:9])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[5]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(par[10],par[11],par[12]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0),
              c(0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,9),1,1,1)
     out_C=constrOptim(init, lmzkip_C, NULL, ui=u_i, ci=c_i)


##################### Case: Proposed model from frequency table of data

  lmzkip_P <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par_p[1:9])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(par[10],par[11],par[12]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0),
              c(0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,9),1,1,1)
     out_P=constrOptim(init, lmzkip_P, NULL, ui=u_i, ci=c_i)

out_full$value
out_CI$value
out_CII$value
out_CIII$value
out_P$value
out_C$value
out_P$value
sum(-log(fmp(y,c(mean(y1),mean(y2),mean(y3)))))


round(out_full$par,4)
round(out_CI$par,4)
round(out_CII$par,4)
round(out_CIII$par,4)
round(out_P$par,4)
round(out_C$par,4)

#########################
s=3
l=sum(-log(fmp(y,c(mean(y1),mean(y2),mean(y3)))))
AIC=2*l+2*s
BIC=2*l+s*log(n)
AICC=2*l+2*s*(n/n-s-1)
CAIC=2*l+s*(log(n)+1)
AIC
BIC
AICC
CAIC
###############################################################
########################################################### OBS
####################################################################
par_f=scan()
 0.2021461716 0.0572327002 0.0150672964 0.0005068606 0.0001234826
 0.0000013644 0.0000234057 0.0001687572 0.0013601773 0.1129687984
 0.0668709509 0.0325179677 0.0047758226 0.0032794628 0.0005646077
 0.0006033743 0.0002999973 0.0000815576 0.0414214978 0.0342396008
 0.0154966808 0.0006808103 0.0002614692 0.0003826749 0.0004996277
 0.0001731671 0.0003861812 2.7040917467 2.3616409888 2.5080726989

par_ci=scan()
0.1807151548 0.0000000049 0.0000000441 1.7722305428 1.0522482650
1.5038601210

par_cii=scan()
0.0904744721 0.0000000022 0.0460434918 1.5539227291 0.9964353937
1.3563795964

par_ciii=scan()
0.0184890295 0.0000000152 0.0010277737 1.4165512790 0.8803388072
1.2399275875

par_c=scan()
0.1928368016 0.0006411716 0.0004786492 0.1182953209 0.0000000618
0.0656289096 0.0452784653 0.0000002261 0.0151486890 2.1837690520
1.5269762608 1.9846871191

par_p=scan()
0.19687379 0.08197660 0.03614456 0.11678022 0.01814815 0.04263219
0.04753442 0.02503701 0.06822763 2.64571407 2.36406714 2.37663478

###############################################################
########################################################### OBS
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
yo=rbind(c(0,0,0),c(0,0,1),c(2,0,0),c(1,0,1),c(1,0,2),c(1,0,0),c(2,0,1),c(0,0,2),c(2,0,2))
########################## ZKIPOISSON
#####################################
##########################CI
  mzkip_CI <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(par_ci[1]+par_ci[2]+par_ci[3]))
     for(i in 1:nn)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_ci[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_ci[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_ci[3]
      d[i]=ww * fmp(y[i,],c(par_ci[4],par_ci[5],par_ci[6]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CI(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CI=po*n

##########################CII
  mzkip_CII <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(par_cii[1]+par_cii[2]+par_cii[3]))
     for(i in 1:nn)
     {
      if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_cii[1]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_cii[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_cii[3]
      d[i]=ww * fmp(y[i,],c(par_cii[4],par_cii[5],par_cii[6]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CII(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CII=po*n

##########################CIII
  mzkip_CIII <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(par_ci[1]+par_ci[2]+par_ci[3]))
     for(i in 1:nn)
     {
      if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_ciii[1]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_ciii[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_ciii[3]
      d[i]=ww * fmp(y[i,],c(par_ciii[4],par_ciii[5],par_ciii[6]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CIII(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CIII=po*n

##########################C
  mzkip_C <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(sum(par_c[1:9])))
     for(i in 1:nn)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par_c[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par_c[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[4]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par_c[5]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_c[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_c[7]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par_c[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_c[9]
      d[i]=ww * fmp(y[i,],c(par_c[10],par_c[11],par_c[12]))+d[i]
     }
     d
    }

##############################

p_obs=mzkip_C(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_C=po*n

########################## FULL
mzkip_full <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(sum(par_f[1:27])))
     for(i in 1:nn)
     {
      if((y[i,1]==yy[1,1])&(y[i,2]==yy[1,2])&(y[i,3]==yy[1,3])) d[i]=par_f[1]
      else if((y[i,1]==yy[2,1])&(y[i,2]==yy[2,2])&(y[i,3]==yy[2,3])) d[i]=par_f[2]
      else if((y[i,1]==yy[3,1])&(y[i,2]==yy[3,2])&(y[i,3]==yy[3,3])) d[i]=par_f[3]
      else if((y[i,1]==yy[4,1])&(y[i,2]==yy[4,2])&(y[i,3]==yy[4,3])) d[i]=par_f[4]
      else if((y[i,1]==yy[5,1])&(y[i,2]==yy[5,2])&(y[i,3]==yy[5,3])) d[i]=par_f[5]
      else if((y[i,1]==yy[6,1])&(y[i,2]==yy[6,2])&(y[i,3]==yy[6,3])) d[i]=par_f[6]
      else if((y[i,1]==yy[7,1])&(y[i,2]==yy[7,2])&(y[i,3]==yy[7,3])) d[i]=par_f[7]
      else if((y[i,1]==yy[8,1])&(y[i,2]==yy[8,2])&(y[i,3]==yy[8,3])) d[i]=par_f[8]
      else if((y[i,1]==yy[9,1])&(y[i,2]==yy[9,2])&(y[i,3]==yy[9,3])) d[i]=par_f[9]
      else if((y[i,1]==yy[10,1])&(y[i,2]==yy[10,2])&(y[i,3]==yy[10,3])) d[i]=par_f[10]
      else if((y[i,1]==yy[11,1])&(y[i,2]==yy[11,2])&(y[i,3]==yy[11,3])) d[i]=par_f[11]
      else if((y[i,1]==yy[12,1])&(y[i,2]==yy[12,2])&(y[i,3]==yy[12,3])) d[i]=par_f[12]
      else if((y[i,1]==yy[13,1])&(y[i,2]==yy[13,2])&(y[i,3]==yy[13,3])) d[i]=par_f[13]
      else if((y[i,1]==yy[14,1])&(y[i,2]==yy[14,2])&(y[i,3]==yy[14,3])) d[i]=par_f[14]
      else if((y[i,1]==yy[15,1])&(y[i,2]==yy[15,2])&(y[i,3]==yy[15,3])) d[i]=par_f[15]
      else if((y[i,1]==yy[16,1])&(y[i,2]==yy[16,2])&(y[i,3]==yy[16,3])) d[i]=par_f[16]
      else if((y[i,1]==yy[17,1])&(y[i,2]==yy[17,2])&(y[i,3]==yy[17,3])) d[i]=par_f[17]
      else if((y[i,1]==yy[18,1])&(y[i,2]==yy[18,2])&(y[i,3]==yy[18,3])) d[i]=par_f[18]
      else if((y[i,1]==yy[19,1])&(y[i,2]==yy[19,2])&(y[i,3]==yy[19,3])) d[i]=par_f[19]
      else if((y[i,1]==yy[20,1])&(y[i,2]==yy[20,2])&(y[i,3]==yy[20,3])) d[i]=par_f[20]
      else if((y[i,1]==yy[21,1])&(y[i,2]==yy[21,2])&(y[i,3]==yy[21,3])) d[i]=par_f[21]
      else if((y[i,1]==yy[22,1])&(y[i,2]==yy[22,2])&(y[i,3]==yy[22,3])) d[i]=par_f[22]
      else if((y[i,1]==yy[23,1])&(y[i,2]==yy[23,2])&(y[i,3]==yy[23,3])) d[i]=par_f[23]
      else if((y[i,1]==yy[24,1])&(y[i,2]==yy[24,2])&(y[i,3]==yy[24,3])) d[i]=par_f[24]
      else if((y[i,1]==yy[25,1])&(y[i,2]==yy[25,2])&(y[i,3]==yy[25,3])) d[i]=par_f[25]
      else if((y[i,1]==yy[26,1])&(y[i,2]==yy[26,2])&(y[i,3]==yy[26,3])) d[i]=par_f[26]
      else if((y[i,1]==yy[27,1])&(y[i,2]==yy[27,2])&(y[i,3]==yy[27,3])) d[i]=par_f[27]
      d[i]=ww * fmp(y[i,],c(par_f[28],par_f[29],par_f[30]))+d[i]
     }
     d
    }
##########################

p_obs=mzkip_full(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_full=po*n

##########################PROPOSED MODEL
  mzkip_P <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(sum(par[1:9])))
     for(i in 1:nn)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_p[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_p[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_p[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_p[4]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_p[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_p[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par_p[7]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par_p[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par_p[9]
      d[i]=ww * fmp(y[i,],c(par_p[10],par_p[11],par_p[12]))+d[i]
     }
     d
    }
p_obs=mzkip_P(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_P=po*n

##########################POISSON
  mzkip_poiss <- function(y) {
     nn=nrow(y)
     d=rep(0,nn)
     for(i in 1:nn)
     {
      d[i]= fmp(yy[i,],c(mean(y1),mean(y1),mean(y1)))
     }
     d
    }
p_obs=mzkip_poiss(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_poiss=po*n
######################################CHI SQ and ABE
########################REAL OBS
jj=jjj=0
ind=c()
n=nrow(y)
nn=nrow(yo)
ii=rep(0,nn)
for(i in 1:nn)
{
 if(jj!=0)
  {
   jjj=jjj+1
   ind[jjj]=(i-1)
  }
 jj=0
 for(j in 1:n)
 {
  if((y[j,1]==yo[i,1])&(y[j,2]==yo[i,2])&(y[j,3]==yo[i,3]))
  {
   ii[i]=ii[i]+1
   jj=1+jj
  }
 }
}


obs=c(ii,(n-sum(ii)))
#####################################CI
ABE_CI=sum(abs(obs-e_CI))
ki_CI=sum(((e_CI-obs)^2)/e_CI)
round(ABE_CI,2)
round(ki_CI,2)
#####################################CII
ABE_CII=sum(abs(obs-e_CII))
ki_CII=sum(((e_CII-obs)^2)/e_CII)
round(ABE_CII,2)
round(ki_CII,2)
#####################################CIII
ABE_CIII=sum(abs(obs-e_CIII))
ki_CIII=sum(((e_CIII-obs)^2)/e_CIII)
round(ABE_CIII,2)
round(ki_CIII,2)
#####################################C
ABE_C=sum(abs(obs-e_C))
ki_C=sum(((e_C-obs)^2)/e_C)
round(ABE_C,2)
round(ki_C,2)
#####################################full
ABE_full=sum(abs(obs-e_full))
ki_full=sum(((e_full-obs)^2)/e_full)
round(ABE_full,2)
round(ki_full,2)
#####################################P
ABE_P=sum(abs(obs-e_P))
ki_P=sum(((e_P-obs)^2)/e_P)
round(ABE_P,2)
round(ki_P,2)
#####################################POISS
ABE_poiss=sum(abs(obs-e_poiss))
ki_poiss=sum(((e_poiss-obs)^2)/e_poiss)
round(ABE_poiss,2)
round(ki_poiss,2)

####################################################################
######################################################STANDARD ERORE
library(numDeriv)
fmp1=function(la)
{
 d=rep(0,n)
  for(i in 1:n)
  {
  
   d[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
     return(-sum(log(d)))
}

hess_CI=hessian(func=lmzkip_CI, x=out_CI$par)
hess_CII=hessian(func=lmzkip_CII, x=out_CII$par)
hess_CIII=hessian(func=lmzkip_CIII, x=out_CIII$par)
hess_C=hessian(func=lmzkip_C, x=out_C$par)
hess_P=hessian(func=lmzkip_P, x=out_P$par)
hess_full=hessian(func=lmzkip_full, x=out_full$par)
hess_pois=hessian(func=fmp1, x=c(mean(y1),mean(y2),mean(y3)))


####CI
round(sqrt(1/diag(hess_CI)),4)

####CII
round(sqrt(1/diag(hess_CII)),4)

####CIII
round(sqrt(1/diag(hess_CII)),4)

####C
round(sqrt(1/diag(hess_C)),4)

####P
round(sqrt(1/diag(hess_P)),4)

####full
round(sqrt(1/diag(hess_full)),4)

####POISS
round(sqrt(1/diag(hess_pois)),4)


