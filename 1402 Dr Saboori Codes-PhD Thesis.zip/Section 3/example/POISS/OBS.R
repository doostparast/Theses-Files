rm(list=ls(all=TRUE))
library(gtools)
k=5
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
nn=nrow(yy)
ii=rep(0,nn)
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib

  y=cbind(y2,y3,y4)
jj=jjj=0
ind=c()
n=nrow(y)
for(i in 1:nn)
{
 if(jj!=0)
  {
   jjj=jjj+1
   ind[jjj]=(i-1)
  }
 jj=0
 for(j in 1:n)
 {
  if((y[j,1]==yy[i,1])&(y[j,2]==yy[i,2])&(y[j,3]==yy[i,3]))
  {
   ii[i]=ii[i]+1
   jj=1+jj
  }
 }
}

cbind(yy[ind,],ii[ii!=0])

