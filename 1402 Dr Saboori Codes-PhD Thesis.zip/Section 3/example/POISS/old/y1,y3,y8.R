rm(list=ls(all=TRUE))
library(gtools)
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib

y=cbind(y1,y3,y8)
n=nrow(y)
############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}

############################################ MLE
################################################

########################################### Case I
 oute_CI_par=matrix(0,1,6)

  lmzkip_CI <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
     out_CI=constrOptim(init, lmzkip_CI, NULL, ui=u_i, ci=c_i)

########################################### Case II
 oute_CII_par=matrix(0,1,6)

  lmzkip_CII <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
     out_CII=constrOptim(init, lmzkip_CII, NULL, ui=u_i, ci=c_i)


########################################### Case III
 oute_CIII_par=matrix(0,1,6)

  lmzkip_CIII <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
     out_CIII=constrOptim(init, lmzkip_CIII, NULL, ui=u_i, ci=c_i)

##################### Case: full model
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)

 oute_full_par=matrix(0,1,30)

  lmzkip_full <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:27])))
     for(i in 1:n)
     {
      if((y[i,1]==yy[1,1])&(y[i,1]==yy[1,2])&(y[i,3]==yy[1,3])) d[i]=par[1]
      else if((y[i,1]==yy[2,1])&(y[i,2]==yy[2,2])&(y[i,3]==yy[2,3])) d[i]=par[2]
      else if((y[i,1]==yy[3,1])&(y[i,2]==yy[3,2])&(y[i,3]==yy[3,3])) d[i]=par[3]
      else if((y[i,1]==yy[4,1])&(y[i,2]==yy[4,2])&(y[i,3]==yy[4,3])) d[i]=par[4]
      else if((y[i,1]==yy[5,1])&(y[i,2]==yy[5,2])&(y[i,3]==yy[5,3])) d[i]=par[5]
      else if((y[i,1]==yy[6,1])&(y[i,2]==yy[6,2])&(y[i,3]==yy[6,3])) d[i]=par[6]
      else if((y[i,1]==yy[7,1])&(y[i,2]==yy[7,2])&(y[i,3]==yy[7,3])) d[i]=par[7]
      else if((y[i,1]==yy[8,1])&(y[i,2]==yy[8,2])&(y[i,3]==yy[8,3])) d[i]=par[8]
      else if((y[i,1]==yy[9,1])&(y[i,2]==yy[9,2])&(y[i,3]==yy[9,3])) d[i]=par[9]
      else if((y[i,1]==yy[10,1])&(y[i,2]==yy[10,2])&(y[i,3]==yy[10,3])) d[i]=par[10]
      else if((y[i,1]==yy[11,1])&(y[i,2]==yy[11,2])&(y[i,3]==yy[11,3])) d[i]=par[11]
      else if((y[i,1]==yy[12,1])&(y[i,2]==yy[12,2])&(y[i,3]==yy[12,3])) d[i]=par[12]
      else if((y[i,1]==yy[13,1])&(y[i,2]==yy[13,2])&(y[i,3]==yy[13,3])) d[i]=par[13]
      else if((y[i,1]==yy[14,1])&(y[i,2]==yy[14,2])&(y[i,3]==yy[14,3])) d[i]=par[14]
      else if((y[i,1]==yy[15,1])&(y[i,2]==yy[15,2])&(y[i,3]==yy[15,3])) d[i]=par[15]
      else if((y[i,1]==yy[16,1])&(y[i,2]==yy[16,2])&(y[i,3]==yy[16,3])) d[i]=par[16]
      else if((y[i,1]==yy[17,1])&(y[i,2]==yy[17,2])&(y[i,3]==yy[17,3])) d[i]=par[17]
      else if((y[i,1]==yy[18,1])&(y[i,2]==yy[18,2])&(y[i,3]==yy[18,3])) d[i]=par[18]
      else if((y[i,1]==yy[19,1])&(y[i,2]==yy[19,2])&(y[i,3]==yy[19,3])) d[i]=par[19]
      else if((y[i,1]==yy[20,1])&(y[i,2]==yy[20,2])&(y[i,3]==yy[20,3])) d[i]=par[20]
      else if((y[i,1]==yy[21,1])&(y[i,2]==yy[21,2])&(y[i,3]==yy[21,3])) d[i]=par[21]
      else if((y[i,1]==yy[22,1])&(y[i,2]==yy[22,2])&(y[i,3]==yy[22,3])) d[i]=par[22]
      else if((y[i,1]==yy[23,1])&(y[i,2]==yy[23,2])&(y[i,3]==yy[23,3])) d[i]=par[23]
      else if((y[i,1]==yy[24,1])&(y[i,2]==yy[24,2])&(y[i,3]==yy[24,3])) d[i]=par[24]
      else if((y[i,1]==yy[25,1])&(y[i,2]==yy[25,2])&(y[i,3]==yy[25,3])) d[i]=par[25]
      else if((y[i,1]==yy[26,1])&(y[i,2]==yy[26,2])&(y[i,3]==yy[26,3])) d[i]=par[26]
      else if((y[i,1]==yy[27,1])&(y[i,2]==yy[27,2])&(y[i,3]==yy[27,3])) d[i]=par[27]
      d[i]=ww * fmp(y[i,],c(par[28],par[29],par[30]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),
c(1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.02,nn),c(.01,.01,.01))
     out_full=constrOptim(init, lmzkip_full, NULL, ui=u_i, ci=c_i)

########################################### Case I, II, III
 oute_C_par=matrix(0,1,12)

  lmzkip_C <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:9])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[5]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(par[10],par[11],par[12]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0),
              c(0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,9),1,1,1)
     out_C=constrOptim(init, lmzkip_C, NULL, ui=u_i, ci=c_i)


##################### Case: Proposed model from frequency table of data

  lmzkip_P <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:9])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[8]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(par[10],par[11],par[12]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0),
              c(0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,9),1,1,1)
     out_P=constrOptim(init, lmzkip_P, NULL, ui=u_i, ci=c_i)

out_full$value
out_CI$value
out_CII$value
out_CIII$value
out_C$value
out_P$value

round(out_full$par,4)
round(out_CI$par,4)
round(out_CII$par,4)
round(out_CIII$par,4)
round(out_P$par,4)
round(out_C$par,4)

###############################################################
########################################################### OBS
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
#yy=rbind(c(0,0,0),c(0,0,1),c(2,0,0),c(1,0,1),c(1,0,2),c(1,0,0),c(0,1,0),c(2,0,1),c(1,1,0))
nn=nrow(yy)

########################## ZKIPOISSON
#####################################
##########################CI
yo=rbind(c(0,0,0),c(1,1,1),c(2,2,2))

  mzkip_CI <- function(par) {
     d=rep(0,nn)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:nn)
     {
      if((yo[1,1]==yy[i,1])&(yo[1,2]==yy[i,2])&(yo[1,3]==yy[i,3])) d[i]=par[1]
      else if((yo[2,1]==yy[i,1])&(yo[2,2]==yy[i,2])&(yo[2,3]==yy[i,3])) d[i]=par[2]
      else if((yo[3,1]==yy[i,1])&(yo[3,2]==yy[i,2])&(yo[3,3]==yy[i,3])) d[i]=par[3]
      d[i]=ww * fmp(yy[i,],c(par[4],par[5],par[6]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CI(out_CI$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CI=po*n

##########################CII
yo=rbind(c(1,0,0),c(0,1,0),c(0,0,1))
  mzkip_CII <- function(par) {
     d=rep(0,nn)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:nn)
     {
      if((yo[1,1]==yy[i,1])&(yo[1,2]==yy[i,2])&(yo[1,3]==yy[i,3])) d[i]=par[1]
      else if((yo[2,1]==yy[i,1])&(yo[2,2]==yy[i,2])&(yo[2,3]==yy[i,3])) d[i]=par[2]
      else if((yo[3,1]==yy[i,1])&(yo[3,2]==yy[i,2])&(yo[3,3]==yy[i,3])) d[i]=par[3]
      d[i]=ww * fmp(yy[i,],c(par[4],par[5],par[6]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CII(out_CII$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CII=po*n

##########################CIII
yo=rbind(c(2,0,0),c(0,2,0),c(0,0,2))
  mzkip_CIII <- function(par) {
     d=rep(0,nn)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:nn)
     {
      if((yo[1,1]==yy[i,1])&(yo[1,2]==yy[i,2])&(yo[1,3]==yy[i,3])) d[i]=par[1]
      else if((yo[2,1]==yy[i,1])&(yo[2,2]==yy[i,2])&(yo[2,3]==yy[i,3])) d[i]=par[2]
      else if((yo[3,1]==yy[i,1])&(yo[3,2]==yy[i,2])&(yo[3,3]==yy[i,3])) d[i]=par[3]
      d[i]=ww * fmp(yy[i,],c(par[4],par[5],par[6]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CIII(out_CIII$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CIII=po*n

##########################C
yo=rbind(c(0,0,0),c(1,1,1),c(2,2,2),c(1,0,0),c(0,1,0),c(0,0,1),c(2,0,0),c(0,2,0),c(0,0,2))
  mzkip_C <- function(par) {
     d=rep(0,nn)
     ww=(1-(sum(par[1:9])))
     for(i in 1:nn)
     {
      if((yy[i,1]==yo[1,1])&(yy[i,2]==yo[1,2])&(yy[i,3]==yo[1,3])) d[i]=par[1]
      else if((yy[i,1]==yo[2,1])&(yy[i,2]==yo[2,2])&(yy[i,3]==yo[2,3])) d[i]=par[2]
      else if((yy[i,1]==yo[3,1])&(yy[i,2]==yo[3,2])&(yy[i,3]==yo[3,3])) d[i]=par[3]
      else if((yy[i,1]==yo[4,1])&(yy[i,2]==yo[4,2])&(yy[i,3]==yo[4,3])) d[i]=par[4]
      else if((yy[i,1]==yo[5,1])&(yy[i,2]==yo[5,2])&(yy[i,3]==yo[5,3])) d[i]=par[5]
      else if((yy[i,1]==yo[6,1])&(yy[i,2]==yo[6,2])&(yy[i,3]==yo[6,3])) d[i]=par[6]
      else if((yy[i,1]==yo[7,1])&(yy[i,2]==yo[7,2])&(yy[i,3]==yo[7,3])) d[i]=par[7]
      else if((yy[i,1]==yo[8,1])&(yy[i,2]==yo[8,2])&(yy[i,3]==yo[8,3])) d[i]=par[8]
      else if((yy[i,1]==yo[9,1])&(yy[i,2]==yo[9,2])&(yy[i,3]==yo[9,3])) d[i]=par[9]
      d[i]=ww * fmp(yy[i,],c(par[10],par[11],par[12]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_C(out_C$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_C=po*n

########################## FULL

p_obs=out_full$par[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_full=po*n

##########################PROPOSED MODEL
yo=rbind(c(0,0,0),c(0,0,1),c(2,0,0),c(1,0,1),c(1,0,2),c(1,0,0),c(0,1,0),c(2,0,1),c(1,1,0))
  mzkip_P <- function(par) {
     d=rep(0,nn)
     ww=(1-(sum(par[1:9])))
     for(i in 1:nn)
     {
      if((yy[i,1]==yo[1,1])&(yy[i,2]==yo[1,2])&(yy[i,3]==yo[1,3])) d[i]=par[1]
      else if((yy[i,1]==yo[2,1])&(yy[i,2]==yo[2,2])&(yy[i,3]==yo[2,3])) d[i]=par[2]
      else if((yy[i,1]==yo[3,1])&(yy[i,2]==yo[3,2])&(yy[i,3]==yo[3,3])) d[i]=par[3]
      else if((yy[i,1]==yo[4,1])&(yy[i,2]==yo[4,2])&(yy[i,3]==yo[4,3])) d[i]=par[4]
      else if((yy[i,1]==yo[5,1])&(yy[i,2]==yo[5,2])&(yy[i,3]==yo[5,3])) d[i]=par[5]
      else if((yy[i,1]==yo[6,1])&(yy[i,2]==yo[6,2])&(yy[i,3]==yo[6,3])) d[i]=par[6]
      else if((yy[i,1]==yo[7,1])&(yy[i,2]==yo[7,2])&(yy[i,3]==yo[7,3])) d[i]=par[7]
      else if((yy[i,1]==yo[8,1])&(yy[i,2]==yo[8,2])&(yy[i,3]==yo[8,3])) d[i]=par[8]
      else if((yy[i,1]==yo[9,1])&(yy[i,2]==yo[9,2])&(yy[i,3]==yo[9,3])) d[i]=par[9]
      d[i]=ww * fmp(yy[i,],c(par[10],par[11],par[12]))+d[i]
     }
     d
    }
p_obs=mzkip_P(out_P$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_P=po*n

######################################CHI SQ and ABE
########################REAL OBS
jj=jjj=0
ind=c()
n=nrow(y)
nn=nrow(yy)
ii=rep(0,nn)
for(i in 1:nn)
{
 if(jj!=0)
  {
   jjj=jjj+1
   ind[jjj]=(i-1)
  }
 jj=0
 for(j in 1:n)
 {
  if((y[j,1]==yy[i,1])&(y[j,2]==yy[i,2])&(y[j,3]==yy[i,3]))
  {
   ii[i]=ii[i]+1
   jj=1+jj
  }
 }
}

obs=c(ii,(n-sum(ii)))
#####################################CI
ABE_CI=sum(abs(obs-e_CI))
ki_CI=sum(((e_CI-obs)^2)/e_CI)
round(ABE_CI,2)
round(ki_CI,2)
#####################################CII
ABE_CII=sum(abs(obs-e_CII))
ki_CII=sum(((e_CII-obs)^2)/e_CII)
round(ABE_CII,2)
round(ki_CII,2)
#####################################CIII
ABE_CIII=sum(abs(obs-e_CIII))
ki_CIII=sum(((e_CIII-obs)^2)/e_CIII)
round(ABE_CIII,2)
round(ki_CIII,2)
#####################################C
ABE_C=sum(abs(obs-e_C))
ki_C=sum(((e_C-obs)^2)/e_C)
round(ABE_C,2)
round(ki_C,2)
#####################################full
ABE_full=sum(abs(obs-e_full))
ki_full=sum(((e_full-obs)^2)/e_full)
round(ABE_full,2)
round(ki_full,2)
#####################################P
ABE_P=sum(abs(obs-e_P))
ki_P=sum(((e_P-obs)^2)/e_P)
round(ABE_P,2)
round(ki_P,2)


