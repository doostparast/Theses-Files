rm(list=ls(all=TRUE))
library(gtools)
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib

y=cbind(y1,y2,y8)
n=nrow(y)
############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}

############################################ MLE
#########################################w[002]=0
#################### Case: Proposed model from frequency table of data

  lmzkip_P1 <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:8])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[8]
      d[i]=ww * fmp(y[i,],c(par[9],par[10],par[11]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,8),1,1,1)
     out_P1=constrOptim(init, lmzkip_P1, NULL, ui=u_i, ci=c_i)
#########################################w[102]=0
#################### Case: Proposed model from frequency table of data

  lmzkip_P2 <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:8])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[8]
      d[i]=ww * fmp(y[i,],c(par[9],par[10],par[11]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,8),1,1,1)
     out_P2=constrOptim(init, lmzkip_P2, NULL, ui=u_i, ci=c_i)
#########################################w[200]=0
#################### Case: Proposed model from frequency table of data

  lmzkip_P3 <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:8])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[5]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[8]
      d[i]=ww * fmp(y[i,],c(par[9],par[10],par[11]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,8),1,1,1)
     out_P3=constrOptim(init, lmzkip_P3, NULL, ui=u_i, ci=c_i)

########################################################proposed model


 lmzkip_P <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:9])))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(par[10],par[11],par[12]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0),
              c(0,0,0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0),
              c(0,0,0,0,0,0,0,0,0,0,0,1))
     init=c(rep(0.01,9),1,1,1)
     out_P=constrOptim(init, lmzkip_P, NULL, ui=u_i, ci=c_i)

#########################################################test in p model
#############################################################vs full model
l_full=out_P$value
l=out_P3$value
s_full=12
s1=11
li=l-l_full
0.5*(1-pchisq(li,s_full-s1))
li

> out_P$value
[1] 23847.94
> out_P1$value
[1] 24068.37
> out_P2$value
[1] 24229.42
> out_P3$value
[1] 24524.28
> 

