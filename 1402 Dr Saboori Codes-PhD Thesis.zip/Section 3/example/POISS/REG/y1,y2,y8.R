rm(list=ls(all=TRUE))
library(gtools)

#######################################
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y8=xx$medicine


u1=xx$sex
u2=xx$age
y=cbind(y1,y2,y8)
n=nrow(y)
############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}
############################################ MLE
################################################

########################################### Case I
 oute_CI_par=matrix(0,1,6)

  lmzkip_CI <- function(par) {
     d=rep(0,n)
     la1=exp(par[4]+par[5]*u1+par[6]*u2)
     la2=exp(par[7]+par[8]*u1+par[9]*u2)
     la3=exp(par[10]+par[11]*u1+par[12]*u2)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0,0,0,0,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0))
     init=scan()
1.698092e-01  2.787829e-07  1.362072e-08  2.557727e-01  7.006954e-02
5.865564e-01 -5.187906e-01  1.789492e-03  1.258443e+00 -6.684366e-01
3.818106e-01  1.771861e+00

     out_CI=constrOptim(init, lmzkip_CI, NULL, ui=u_i, ci=c_i)


########################################### Case II
 oute_CII_par=matrix(0,1,6)

  lmzkip_CII <-  function(par) {
     d=rep(0,n)
     la1=exp(par[4]+par[5]*u1+par[6]*u2)
     la2=exp(par[7]+par[8]*u1+par[9]*u2)
     la3=exp(par[10]+par[11]*u1+par[12]*u2)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0,0,0,0,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0))
     init=scan()
6.574075e-02  1.357865e-08  4.328335e-02 -4.781027e-02  1.824527e-01
8.742548e-01 -7.049406e-01  1.077677e-01  1.396920e+00 -9.235851e-01
4.901303e-01  1.977666e+00


     out_CII=constrOptim(init, lmzkip_CII, NULL, ui=u_i, ci=c_i)


########################################### Case III

  lmzkip_CIII <-  function(par) {
     d=rep(0,n)
     la1=exp(par[4]+par[5]*u1+par[6]*u2)
     la2=exp(par[7]+par[8]*u1+par[9]*u2)
     la3=exp(par[10]+par[11]*u1+par[12]*u2)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0,0,0,0,0,0,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0))
     init=scan()
0.0143467079  0.0000000268  0.0048429640 -0.1081668220  0.1656060341
0.8751689457 -0.8360103138  0.0931209204  1.4822330033 -0.9822643934
0.4826424453  1.9687093710


     out_CIII=constrOptim(init, lmzkip_CIII, NULL, ui=u_i, ci=c_i)


##################### Case: full model
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
nn=nrow(yy)

  lmzkip_full <- function(par) {
     d=rep(0,n)
     la1=exp(par[28]+par[29]*u1+par[30]*u2)
     la2=exp(par[31]+par[32]*u1+par[33]*u2)
     la3=exp(par[34]+par[35]*u1+par[36]*u2)
     ww=(1-(sum(par[1:27])))
     for(i in 1:n)
     {
      if((y[i,1]==yy[1,1])&(y[i,2]==yy[1,2])&(y[i,3]==yy[1,3])) d[i]=par[1]
      else if((y[i,1]==yy[2,1])&(y[i,2]==yy[2,2])&(y[i,3]==yy[2,3])) d[i]=par[2]
      else if((y[i,1]==yy[3,1])&(y[i,2]==yy[3,2])&(y[i,3]==yy[3,3])) d[i]=par[3]
      else if((y[i,1]==yy[4,1])&(y[i,2]==yy[4,2])&(y[i,3]==yy[4,3])) d[i]=par[4]
      else if((y[i,1]==yy[5,1])&(y[i,2]==yy[5,2])&(y[i,3]==yy[5,3])) d[i]=par[5]
      else if((y[i,1]==yy[6,1])&(y[i,2]==yy[6,2])&(y[i,3]==yy[6,3])) d[i]=par[6]
      else if((y[i,1]==yy[7,1])&(y[i,2]==yy[7,2])&(y[i,3]==yy[7,3])) d[i]=par[7]
      else if((y[i,1]==yy[8,1])&(y[i,2]==yy[8,2])&(y[i,3]==yy[8,3])) d[i]=par[8]
      else if((y[i,1]==yy[9,1])&(y[i,2]==yy[9,2])&(y[i,3]==yy[9,3])) d[i]=par[9]
      else if((y[i,1]==yy[10,1])&(y[i,2]==yy[10,2])&(y[i,3]==yy[10,3])) d[i]=par[10]
      else if((y[i,1]==yy[11,1])&(y[i,2]==yy[11,2])&(y[i,3]==yy[11,3])) d[i]=par[11]
      else if((y[i,1]==yy[12,1])&(y[i,2]==yy[12,2])&(y[i,3]==yy[12,3])) d[i]=par[12]
      else if((y[i,1]==yy[13,1])&(y[i,2]==yy[13,2])&(y[i,3]==yy[13,3])) d[i]=par[13]
      else if((y[i,1]==yy[14,1])&(y[i,2]==yy[14,2])&(y[i,3]==yy[14,3])) d[i]=par[14]
      else if((y[i,1]==yy[15,1])&(y[i,2]==yy[15,2])&(y[i,3]==yy[15,3])) d[i]=par[15]
      else if((y[i,1]==yy[16,1])&(y[i,2]==yy[16,2])&(y[i,3]==yy[16,3])) d[i]=par[16]
      else if((y[i,1]==yy[17,1])&(y[i,2]==yy[17,2])&(y[i,3]==yy[17,3])) d[i]=par[17]
      else if((y[i,1]==yy[18,1])&(y[i,2]==yy[18,2])&(y[i,3]==yy[18,3])) d[i]=par[18]
      else if((y[i,1]==yy[19,1])&(y[i,2]==yy[19,2])&(y[i,3]==yy[19,3])) d[i]=par[19]
      else if((y[i,1]==yy[20,1])&(y[i,2]==yy[20,2])&(y[i,3]==yy[20,3])) d[i]=par[20]
      else if((y[i,1]==yy[21,1])&(y[i,2]==yy[21,2])&(y[i,3]==yy[21,3])) d[i]=par[21]
      else if((y[i,1]==yy[22,1])&(y[i,2]==yy[22,2])&(y[i,3]==yy[22,3])) d[i]=par[22]
      else if((y[i,1]==yy[23,1])&(y[i,2]==yy[23,2])&(y[i,3]==yy[23,3])) d[i]=par[23]
      else if((y[i,1]==yy[24,1])&(y[i,2]==yy[24,2])&(y[i,3]==yy[24,3])) d[i]=par[24]
      else if((y[i,1]==yy[25,1])&(y[i,2]==yy[25,2])&(y[i,3]==yy[25,3])) d[i]=par[25]
      else if((y[i,1]==yy[26,1])&(y[i,2]==yy[26,2])&(y[i,3]==yy[26,3])) d[i]=par[26]
      else if((y[i,1]==yy[27,1])&(y[i,2]==yy[27,2])&(y[i,3]==yy[27,3])) d[i]=par[27]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0,0,0,0,0,0,0),
c(1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0))

     init=scan()
0.1951876645  8.596549e-02  9.985216e-03  4.499480e-04  7.071859e-04
2.389825e-03  8.554314e-04  5.903173e-04  7.309340e-04  1.549287e-01
1.188287e-01  2.707409e-02  9.128557e-04  1.083607e-03  3.067736e-05
1.023316e-04  8.672577e-04  4.589801e-04  8.203762e-02  2.715775e-02
1.911919e-02  2.222661e-04  2.611875e-04  6.562779e-05  4.283017e-05
1.937979e-03  1.599356e-03  8.457131e-01  1.335111e-02  3.533767e-01
8.504690e-01 -1.344418e-01  2.837312e-01  4.181399e-03  2.895327e-01
1.433830e+00


     out_full=constrOptim(init, lmzkip_full, NULL, ui=u_i, ci=c_i)
 out_full
 23512.8-out_full
########################################### Case I, II, III
 oute_C_par=matrix(0,1,12)

  lmzkip_C <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:9])))
     la1=exp(par[10]+par[11]*u1+par[12]*u2)
     la2=exp(par[13]+par[14]*u1+par[15]*u2)
     la3=exp(par[16]+par[17]*u1+par[18]*u2)
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==2)&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[5]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==0)&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0,0,0,0,0,0,0),
              c(1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0))
     init=scan()
1.929115e-01  3.255003e-05  1.314260e-08  1.066098e-01  4.379876e-06
6.483683e-02  3.893443e-02  1.367361e-05  1.419345e-02  5.269095e-01
2.556001e-03  5.243627e-01  7.620567e-02 -1.286018e-01  8.709693e-01
3.306914e-03  2.024290e-01  1.199961e+00

     out_C=constrOptim(init, lmzkip_C, NULL, ui=u_i, ci=c_i)


##################### Case: Proposed model from frequency table of data

  lmzkip_P <- function(par) {
     d=rep(0,n)
     ww=(1-(sum(par[1:9])))
     la1=exp(par[10]+par[11]*u1+par[12]*u2)
     la2=exp(par[13]+par[14]*u1+par[15]*u2)
     la3=exp(par[16]+par[17]*u1+par[18]*u2)
     for(i in 1:n)
     {
      if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==1)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[5]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[6]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==2)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[8]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[9]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,0,0,0,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0,0,0,0,0,0,0,0,0),
              c(1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
              c(0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
              c(0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0),
              c(0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
              c(0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0))
     init=scan()
0.1964297081  0.0822873242  0.0368640398  0.1179906044  0.0182629766
0.0416377476  0.0463681162  0.0250046309  0.0687894179  0.8278652969
-0.0045720455  0.3317597976  0.8240530166 -0.1688245059  0.3075256170
0.0009916773  0.2688705219  1.4050379688

     out_P=constrOptim(init, lmzkip_P, NULL, ui=u_i, ci=c_i)
 out_P
 23512.67-out_P$value
#####################POISSON

  lmzkip_pois <- function(par) {
     d=rep(0,n)
     la1=exp(par[1]+par[2]*u1+par[3]*u2)
     la2=exp(par[4]+par[5]*u1+par[6]*u2)
     la3=exp(par[7]+par[8]*u1+par[9]*u2)
     for(i in 1:n)
     {
      d[i]=fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

     init=c(1,1,1,1,1,1,1,1,1)
     out_pois=optim(init, lmzkip_pois)



out_full$value
out_CI$value
out_CII$value
out_CIII$value
out_C$value
out_P$value
out_pois$value


round(out_full$par,10)
round(out_CI$par,10)
round(out_CII$par,10)
round(out_CIII$par,10)
round(out_C$par,10)
round(out_P$par,10)
round(out_pois$par,10)

#########################
s=3
l=out_CI$value
AIC=2*l+2*s
BIC=2*l+s*log(n)
AICC=2*l+2*s*(n/n-s-1)
CAIC=2*l+s*(log(n)+1)
AIC
BIC
AICC
CAIC
###############################################################
########################################################### OBS
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
#yy=rbind(c(0,0,0),c(0,0,1),c(2,0,0),c(1,0,1),c(1,0,2),c(1,0,0),c(2,0,1),c(0,0,2),c(2,0,2))
nn=nrow(yy)
########################## ZKIPOISSON
#####################################
##########################CI
yo=rbind(c(0,0,0),c(1,1,1),c(2,2,2))

  mzkip_CI <- function(par) {
     d=rep(0,nn)
     ww=(1-(par[1]+par[2]+par[3]))
     la1=exp(par[4]+par[5]*u1+par[6]*u2)
     la2=exp(par[7]+par[8]*u1+par[9]*u2)
     la3=exp(par[10]+par[11]*u1+par[12]*u2)
     for(i in 1:nn)
     {
      if((yo[1,1]==yy[i,1])&(yo[1,2]==yy[i,2])&(yo[1,3]==yy[i,3])) d[i]=par[1]
      else if((yo[2,1]==yy[i,1])&(yo[2,2]==yy[i,2])&(yo[2,3]==yy[i,3])) d[i]=par[2]
      else if((yo[3,1]==yy[i,1])&(yo[3,2]==yy[i,2])&(yo[3,3]==yy[i,3])) d[i]=par[3]
      d[i]=ww * fmp(yy[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CI(out_CI$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CI=po*n

##########################CII
yo=rbind(c(1,0,0),c(0,1,0),c(0,0,1))
  mzkip_CII <- function(par) {
     d=rep(0,nn)
     ww=(1-(par[1]+par[2]+par[3]))
     la1=exp(par[4]+par[5]*u1+par[6]*u2)
     la2=exp(par[7]+par[8]*u1+par[9]*u2)
     la3=exp(par[10]+par[11]*u1+par[12]*u2)
     for(i in 1:nn)
     {
      if((yo[1,1]==yy[i,1])&(yo[1,2]==yy[i,2])&(yo[1,3]==yy[i,3])) d[i]=par[1]
      else if((yo[2,1]==yy[i,1])&(yo[2,2]==yy[i,2])&(yo[2,3]==yy[i,3])) d[i]=par[2]
      else if((yo[3,1]==yy[i,1])&(yo[3,2]==yy[i,2])&(yo[3,3]==yy[i,3])) d[i]=par[3]
      d[i]=ww * fmp(yy[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CII(out_CII$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CII=po*n

##########################CIII
yo=rbind(c(2,0,0),c(0,2,0),c(0,0,2))
  mzkip_CIII <- function(par) {
     d=rep(0,nn)
     ww=(1-(par[1]+par[2]+par[3]))
     la1=exp(par[4]+par[5]*u1+par[6]*u2)
     la2=exp(par[7]+par[8]*u1+par[9]*u2)
     la3=exp(par[10]+par[11]*u1+par[12]*u2)
     for(i in 1:nn)
     {
      if((yo[1,1]==yy[i,1])&(yo[1,2]==yy[i,2])&(yo[1,3]==yy[i,3])) d[i]=par[1]
      else if((yo[2,1]==yy[i,1])&(yo[2,2]==yy[i,2])&(yo[2,3]==yy[i,3])) d[i]=par[2]
      else if((yo[3,1]==yy[i,1])&(yo[3,2]==yy[i,2])&(yo[3,3]==yy[i,3])) d[i]=par[3]
      d[i]=ww * fmp(yy[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_CIII(out_CIII$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_CIII=po*n

##########################C
yo=rbind(c(0,0,0),c(1,1,1),c(2,2,2),c(1,0,0),c(0,1,0),c(0,0,1),c(2,0,0),c(0,2,0),c(0,0,2))
  mzkip_C <- function(par) {
     d=rep(0,nn)
     ww=(1-(sum(par[1:9])))
     la1=exp(par[10]+par[11]*u1+par[12]*u2)
     la2=exp(par[13]+par[14]*u1+par[15]*u2)
     la3=exp(par[16]+par[17]*u1+par[18]*u2)
     for(i in 1:nn)
     {
      if((yy[i,1]==yo[1,1])&(yy[i,2]==yo[1,2])&(yy[i,3]==yo[1,3])) d[i]=par[1]
      else if((yy[i,1]==yo[2,1])&(yy[i,2]==yo[2,2])&(yy[i,3]==yo[2,3])) d[i]=par[2]
      else if((yy[i,1]==yo[3,1])&(yy[i,2]==yo[3,2])&(yy[i,3]==yo[3,3])) d[i]=par[3]
      else if((yy[i,1]==yo[4,1])&(yy[i,2]==yo[4,2])&(yy[i,3]==yo[4,3])) d[i]=par[4]
      else if((yy[i,1]==yo[5,1])&(yy[i,2]==yo[5,2])&(yy[i,3]==yo[5,3])) d[i]=par[5]
      else if((yy[i,1]==yo[6,1])&(yy[i,2]==yo[6,2])&(yy[i,3]==yo[6,3])) d[i]=par[6]
      else if((yy[i,1]==yo[7,1])&(yy[i,2]==yo[7,2])&(yy[i,3]==yo[7,3])) d[i]=par[7]
      else if((yy[i,1]==yo[8,1])&(yy[i,2]==yo[8,2])&(yy[i,3]==yo[8,3])) d[i]=par[8]
      else if((yy[i,1]==yo[9,1])&(yy[i,2]==yo[9,2])&(yy[i,3]==yo[9,3])) d[i]=par[9]
      d[i]=ww * fmp(yy[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     d
    }
##############################

p_obs=mzkip_C(out_C$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_C=po*n

########################## FULL

################################

#p_obs=out_full$par[1:nn]
p_obs=out_full$par[c(1,2,3,10,11,12,19,20,21)]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_full=po*n

##########################PROPOSED MODEL
yo=rbind(c(0,0,0),c(0,0,1),c(2,0,0),c(1,0,1),c(1,0,2),c(1,0,0),c(2,0,1),c(0,0,2),c(2,0,2))
  mzkip_P <- function(par) {
     d=rep(0,nn)
     ww=(1-(sum(par[1:9])))
     la1=exp(par[10]+par[11]*u1+par[12]*u2)
     la2=exp(par[13]+par[14]*u1+par[15]*u2)
     la3=exp(par[16]+par[17]*u1+par[18]*u2)
     for(i in 1:nn)
     {
      if((yy[i,1]==yo[1,1])&(yy[i,2]==yo[1,2])&(yy[i,3]==yo[1,3])) d[i]=par[1]
      else if((yy[i,1]==yo[2,1])&(yy[i,2]==yo[2,2])&(yy[i,3]==yo[2,3])) d[i]=par[2]
      else if((yy[i,1]==yo[3,1])&(yy[i,2]==yo[3,2])&(yy[i,3]==yo[3,3])) d[i]=par[3]
      else if((yy[i,1]==yo[4,1])&(yy[i,2]==yo[4,2])&(yy[i,3]==yo[4,3])) d[i]=par[4]
      else if((yy[i,1]==yo[5,1])&(yy[i,2]==yo[5,2])&(yy[i,3]==yo[5,3])) d[i]=par[5]
      else if((yy[i,1]==yo[6,1])&(yy[i,2]==yo[6,2])&(yy[i,3]==yo[6,3])) d[i]=par[6]
      else if((yy[i,1]==yo[7,1])&(yy[i,2]==yo[7,2])&(yy[i,3]==yo[7,3])) d[i]=par[7]
      else if((yy[i,1]==yo[8,1])&(yy[i,2]==yo[8,2])&(yy[i,3]==yo[8,3])) d[i]=par[8]
      else if((yy[i,1]==yo[9,1])&(yy[i,2]==yo[9,2])&(yy[i,3]==yo[9,3])) d[i]=par[9]
      d[i]=ww * fmp(yy[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     d
    }
p_obs=mzkip_P(out_P$par)[1:nn]
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_P=po*n

##########################POISSON
  mzkip_poiss <- function(par) {
     d=rep(0,nn)
     la1=exp(par[1]+par[2]*u1+par[3]*u2)
     la2=exp(par[4]+par[5]*u1+par[6]*u2)
     la3=exp(par[7]+par[8]*u1+par[9]*u2)
     for(i in 1:nn)
     {
      d[i]= fmp(yy[i,],c(la1[i],la2[i],la3[i]))
     }
     d
    }
p_obs=mzkip_poiss(out_pois$par)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_poiss=po*n
######################################CHI SQ and ABE
########################REAL OBS
jj=jjj=0
ind=c()
n=nrow(y)
nn=nrow(yy)
ii=rep(0,nn)
for(i in 1:nn)
{
 if(jj!=0)
  {
   jjj=jjj+1
   ind[jjj]=(i-1)
  }
 jj=0
 for(j in 1:n)
 {
  if((y[j,1]==yy[i,1])&(y[j,2]==yy[i,2])&(y[j,3]==yy[i,3]))
  {
   ii[i]=ii[i]+1
   jj=1+jj
  }
 }
}


obs=c(ii,(n-sum(ii)))
#####################################CI
ABE_CI=sum(abs(obs-e_CI))
ki_CI=sum(((e_CI-obs)^2)/e_CI)
round(ABE_CI,2)
round(ki_CI,2)
#####################################CII
ABE_CII=sum(abs(obs-e_CII))
ki_CII=sum(((e_CII-obs)^2)/e_CII)
round(ABE_CII,2)
round(ki_CII,2)
#####################################CIII
ABE_CIII=sum(abs(obs-e_CIII))
ki_CIII=sum(((e_CIII-obs)^2)/e_CIII)
round(ABE_CIII,2)
round(ki_CIII,2)
#####################################C
ABE_C=sum(abs(obs-e_C))
ki_C=sum(((e_C-obs)^2)/e_C)
round(ABE_C,2)
round(ki_C,2)
#####################################full
ABE_full=sum(abs(obs-e_full))
ki_full=sum(((e_full-obs)^2)/e_full)
round(ABE_full,2)
round(ki_full,2)
#####################################P
ABE_P=sum(abs(obs-e_P))
ki_P=sum(((e_P-obs)^2)/e_P)
round(ABE_P,2)
round(ki_P,2)
#####################################POISS
ABE_poiss=sum(abs(obs-e_poiss))
ki_poiss=sum(((e_poiss-obs)^2)/e_poiss)
round(ABE_poiss,2)
round(ki_poiss,2)

####################################################################
######################################################STANDARD ERORE
library(numDeriv)
fmp1=function(par)
{
     la1=exp(par[1]+par[2]*u1+par[3]*u2)
     la2=exp(par[4]+par[5]*u1+par[6]*u2)
     la3=exp(par[7]+par[8]*u1+par[9]*u2)
 d=rep(0,n)
  for(i in 1:n)
  {
  
   d[i]=(dpois(y[i,1],la1[i])*dpois(y[i,2],la2[i])*dpois(y[i,3],la3[i]))
  }
     return(-sum(log(d)))
}

hess_CI=hessian(func=lmzkip_CI, x=out_CI$par)
hess_CII=hessian(func=lmzkip_CII, x=out_CII$par)
hess_CIII=hessian(func=lmzkip_CIII, x=out_CIII$par)
hess_C=hessian(func=lmzkip_C, x=out_C$par)
hess_P=hessian(func=lmzkip_P, x=out_P$par)
hess_full=hessian(func=lmzkip_full, x=out_full$par)
hess_pois=hessian(func=fmp1, x=out_pois$par)


####CI
round(sqrt(1/diag(hess_CI)),4)

####CII
round(sqrt(1/diag(hess_CII)),4)

####CIII
round(sqrt(1/diag(hess_CII)),4)

####C
round(sqrt(1/diag(hess_C)),4)

####P
round(sqrt(1/diag(hess_P)),4)

####full
round(sqrt(1/diag(hess_full)),4)

####POISS
round(sqrt(1/diag(hess_pois)),4)


