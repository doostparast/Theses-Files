rm(list=ls(all=TRUE))
library(gtools)
library(DEoptim)
#######################################
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib

u1=xx$sex
u2=xx$age
y=cbind(y1,y2,y8)
n=nrow(y)
############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}
############################################ MLE
################################################


##################### Case: full model
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
nn=nrow(yy)


  lmzkip_full <- function(par) {
     d=rep(0,n)
     la1=exp(par[28]+par[29]*u1+par[30]*u2)
     la2=exp(par[31]+par[32]*u1+par[33]*u2)
     la3=exp(par[34]+par[35]*u1+par[36]*u2)
     ww=(1-(sum(par[1:27])))
     for(i in 1:n)
     {
      if((y[i,1]==yy[1,1])&(y[i,1]==yy[1,2])&(y[i,3]==yy[1,3])) d[i]=par[1]
      else if((y[i,1]==yy[2,1])&(y[i,2]==yy[2,2])&(y[i,3]==yy[2,3])) d[i]=par[2]
      else if((y[i,1]==yy[3,1])&(y[i,2]==yy[3,2])&(y[i,3]==yy[3,3])) d[i]=par[3]
      else if((y[i,1]==yy[4,1])&(y[i,2]==yy[4,2])&(y[i,3]==yy[4,3])) d[i]=par[4]
      else if((y[i,1]==yy[5,1])&(y[i,2]==yy[5,2])&(y[i,3]==yy[5,3])) d[i]=par[5]
      else if((y[i,1]==yy[6,1])&(y[i,2]==yy[6,2])&(y[i,3]==yy[6,3])) d[i]=par[6]
      else if((y[i,1]==yy[7,1])&(y[i,2]==yy[7,2])&(y[i,3]==yy[7,3])) d[i]=par[7]
      else if((y[i,1]==yy[8,1])&(y[i,2]==yy[8,2])&(y[i,3]==yy[8,3])) d[i]=par[8]
      else if((y[i,1]==yy[9,1])&(y[i,2]==yy[9,2])&(y[i,3]==yy[9,3])) d[i]=par[9]
      else if((y[i,1]==yy[10,1])&(y[i,2]==yy[10,2])&(y[i,3]==yy[10,3])) d[i]=par[10]
      else if((y[i,1]==yy[11,1])&(y[i,2]==yy[11,2])&(y[i,3]==yy[11,3])) d[i]=par[11]
      else if((y[i,1]==yy[12,1])&(y[i,2]==yy[12,2])&(y[i,3]==yy[12,3])) d[i]=par[12]
      else if((y[i,1]==yy[13,1])&(y[i,2]==yy[13,2])&(y[i,3]==yy[13,3])) d[i]=par[13]
      else if((y[i,1]==yy[14,1])&(y[i,2]==yy[14,2])&(y[i,3]==yy[14,3])) d[i]=par[14]
      else if((y[i,1]==yy[15,1])&(y[i,2]==yy[15,2])&(y[i,3]==yy[15,3])) d[i]=par[15]
      else if((y[i,1]==yy[16,1])&(y[i,2]==yy[16,2])&(y[i,3]==yy[16,3])) d[i]=par[16]
      else if((y[i,1]==yy[17,1])&(y[i,2]==yy[17,2])&(y[i,3]==yy[17,3])) d[i]=par[17]
      else if((y[i,1]==yy[18,1])&(y[i,2]==yy[18,2])&(y[i,3]==yy[18,3])) d[i]=par[18]
      else if((y[i,1]==yy[19,1])&(y[i,2]==yy[19,2])&(y[i,3]==yy[19,3])) d[i]=par[19]
      else if((y[i,1]==yy[20,1])&(y[i,2]==yy[20,2])&(y[i,3]==yy[20,3])) d[i]=par[20]
      else if((y[i,1]==yy[21,1])&(y[i,2]==yy[21,2])&(y[i,3]==yy[21,3])) d[i]=par[21]
      else if((y[i,1]==yy[22,1])&(y[i,2]==yy[22,2])&(y[i,3]==yy[22,3])) d[i]=par[22]
      else if((y[i,1]==yy[23,1])&(y[i,2]==yy[23,2])&(y[i,3]==yy[23,3])) d[i]=par[23]
      else if((y[i,1]==yy[24,1])&(y[i,2]==yy[24,2])&(y[i,3]==yy[24,3])) d[i]=par[24]
      else if((y[i,1]==yy[25,1])&(y[i,2]==yy[25,2])&(y[i,3]==yy[25,3])) d[i]=par[25]
      else if((y[i,1]==yy[26,1])&(y[i,2]==yy[26,2])&(y[i,3]==yy[26,3])) d[i]=par[26]
      else if((y[i,1]==yy[27,1])&(y[i,2]==yy[27,2])&(y[i,3]==yy[27,3])) d[i]=par[27]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
     return(-sum(log(d)))
    }

lower=rep(0,36)
upper=c(rep(0,27),rep(2,9))

controlDE <- list(reltol=.000000001,steptol=500, itermax = 10000,trace = 1,
NP=5000)

start <- Sys.time()
out <- DEoptim(fn =lmzkip_full , lower = lower, upper = upper, control = controlDE)
