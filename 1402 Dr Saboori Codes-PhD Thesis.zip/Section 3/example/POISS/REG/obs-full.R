rm(list=ls(all=TRUE))
library(gtools)
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx,1)
y1=xx$illness
y2=xx$actdays
y3=xx$hscore
y4=xx$doctorco
y5=xx$nondocco
y6=xx$hospadmi
y7=xx$hospdays
y8=xx$medicine
y9=xx$prescrib
u1=xx$sex
u2=xx$age
y=cbind(y1,y2,y8)
n=nrow(y)
############################MPOIS
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}


##################### Case: full model
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)

  lmzkip_full <- function(y) {
nn=nrow(y)
     d=rep(0,nn)
     ww=(1-(sum(par[1:27])))
     la1=exp(par[28]+par[29]*u1+par[30]*u2)
     la2=exp(par[31]+par[32]*u1+par[33]*u2)
     la3=exp(par[34]+par[35]*u1+par[36]*u2)
     for(i in 1:nn)
     {
           if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[1]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[2]
      else if((y[i,1]==0)&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[3]
      else if((y[i,1]==0)&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[4]
      else if((y[i,1]==yy[5,1])&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[5]
      else if((y[i,1]==yy[6,1])&(y[i,2]==1)&(y[i,3]==2)) d[i]=par[6]
      else if((y[i,1]==yy[7,1])&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[7]
      else if((y[i,1]==yy[8,1])&(y[i,2]==2)&(y[i,3]==1)) d[i]=par[8]
      else if((y[i,1]==yy[9,1])&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[9]
      else if((y[i,1]==yy[10,1])&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[10]
      else if((y[i,1]==yy[11,1])&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[11]
      else if((y[i,1]==yy[12,1])&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[12]
      else if((y[i,1]==yy[13,1])&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[13]
      else if((y[i,1]==yy[14,1])&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[14]
      else if((y[i,1]==yy[15,1])&(y[i,2]==1)&(y[i,3]==2)) d[i]=par[15]
      else if((y[i,1]==yy[16,1])&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[16]
      else if((y[i,1]==yy[17,1])&(y[i,2]==2)&(y[i,3]==1)) d[i]=par[17]
      else if((y[i,1]==yy[18,1])&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[18]
      else if((y[i,1]==yy[19,1])&(y[i,2]==0)&(y[i,3]==0)) d[i]=par[19]
      else if((y[i,1]==yy[20,1])&(y[i,2]==0)&(y[i,3]==1)) d[i]=par[20]
      else if((y[i,1]==yy[21,1])&(y[i,2]==0)&(y[i,3]==2)) d[i]=par[21]
      else if((y[i,1]==yy[22,1])&(y[i,2]==1)&(y[i,3]==0)) d[i]=par[22]
      else if((y[i,1]==yy[23,1])&(y[i,2]==1)&(y[i,3]==1)) d[i]=par[23]
      else if((y[i,1]==yy[24,1])&(y[i,2]==1)&(y[i,3]==2)) d[i]=par[24]
      else if((y[i,1]==yy[25,1])&(y[i,2]==2)&(y[i,3]==0)) d[i]=par[25]
      else if((y[i,1]==yy[26,1])&(y[i,2]==2)&(y[i,3]==1)) d[i]=par[26]
      else if((y[i,1]==yy[27,1])&(y[i,2]==2)&(y[i,3]==2)) d[i]=par[27]
      d[i]=ww * fmp(y[i,],c(la1[i],la2[i],la3[i]))+d[i]
     }
d
    }

     
par=scan()
0.2  0.0707847910  0.0153166619  0  0
0  0  0  0  0.1095034365
0.0742632596  0.0374002413  0.0033422149  0  0
0  0  0  0.0482606574  0.0427994370
0.0259047549  0  0  0  0
0  0  0.8300548806 -0.0100612436  0.3233871914
0.8204820603 -0.1566694692  0.2855804096  -0.013  0.2652976272
1.4117479858 


l=lmzkip_full(y)
l
23507.41
l-23507.41
s=36

AIC=2*l+2*s
BIC=2*l+s*log(n)
AICC=2*l+2*s*(n/n-s-1)
CAIC=2*l+s*(log(n)+1)
AIC
BIC
AICC
CAIC


###############################################################
########################################################### OBS
k=2
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
yo=rbind(c(0,0,0),c(0,0,1),c(2,0,0),c(1,0,1),c(1,0,2),c(1,0,0),c(2,0,1),c(0,0,2),c(2,0,2))
p_obs=lmzkip_full(yo)
p_remain=1-sum(p_obs)
po=c(p_obs,p_remain)
e_full=po*n

######################################CHI SQ and ABE
########################REAL OBS
jj=jjj=0
ind=c()
n=nrow(y)
nn=nrow(yo)
ii=rep(0,nn)
for(i in 1:nn)
{
 if(jj!=0)
  {
   jjj=jjj+1
   ind[jjj]=(i-1)
  }
 jj=0
 for(j in 1:n)
 {
  if((y[j,1]==yo[i,1])&(y[j,2]==yo[i,2])&(y[j,3]==yo[i,3]))
  {
   ii[i]=ii[i]+1
   jj=1+jj
  }
 }
}


obs=c(ii,(n-sum(ii)))

#####################################full
ABE_full=sum(abs(obs-e_full))
ki_full=sum(((e_full-obs)^2)/e_full)
round(ABE_full,2)
round(ki_full,2)
