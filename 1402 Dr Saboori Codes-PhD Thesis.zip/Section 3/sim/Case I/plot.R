###############################################################POISSON
layout(matrix(c(1,2,3,4), 2, 2, byrow = TRUE))
x = c(10,20,50,100,150,200,250,300,350,400,450,500)
y = c(,,,0.040,0.059,0.034,0.036,0.034,0.052,0.035,0.042,0.039)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated significant level",ylim=c(0,0.08),main=
 bquote("(1)"~w[222]==0))
abline(h=0.05, col="red", lwd=3, lty=2)

############################################################0.01
y = c(0.228,0.382,0.420,0.493,0.536,0.582,0.662,0.659,0.698)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0,1),main=
 bquote("(2)"~w[222]==0.01))

############################################################0.05
y = c(0.946,.991,.992,.999,1,1,1,1,1)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0.9,1),main=
 bquote("(3)"~w[222]==0.05))

############################################################0.1
y = c(.999,1,1,1,1,1,1,1,1)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0.95,1),main=
 bquote("(4)"~w[222]==0.1))

######################################################################
###############################################################NB
y = c(.061,.049,.033,.028,.019,.024,.033,.047,.057)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated significant level",ylim=c(0,.08),main=
 bquote("(1)"~w[222]==0))
abline(h=0.05, col="red", lwd=3, lty=2)

############################################################0.01
y = c(.592,.653,.718,.814,.821,.989,.927,.941,.965)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0,1),main=
 bquote("(2)"~w[222]==0.01))

############################################################0.05
y = c(0.985,.997,1,1,1,1,1,1,1)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0.9,1),main=
 bquote("(3)"~w[222]==0.05))

############################################################0.1
y = c(1,1,1,1,1,1,1,1,1)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0.95,1),main=
 bquote("(4)"~w[222]==0.1))
######################################################################
###############################################################LOG
y = c(.022,.024,.063,.043,.052,.048,.056,.058,.073)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated significant level",ylim=c(0,.08),main=
 bquote("(1)"~w[222]==0))
abline(h=0.05, col="red", lwd=3, lty=2)

############################################################0.01
y = c(.641,.803,.877,.934,.950,.969,.984,.984,.989)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0,1),main=
 bquote("(2)"~w[222]==0.01))

############################################################0.05
y = c(0.994,.999,1,1,1,1,1,1,1)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0.9,1),main=
 bquote("(3)"~w[222]==0.05))

############################################################0.1
y = c(1,1,1,1,1,1,1,1,1)

plot(x,y,type="l",xlab="Sample size",ylab="Simulated mean power",ylim=c(0.95,1),main=
 bquote("(4)"~w[222]==0.1))