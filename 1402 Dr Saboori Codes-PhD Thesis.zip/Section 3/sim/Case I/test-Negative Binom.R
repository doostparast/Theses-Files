rm(list=ls(all=TRUE))
library(gtools)
r=2
k=15
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
fmnb=function(y,pp)
{
 if(!(is.matrix(y)))
 {
  fout=(pp[1]^y[1])*(pp[2]^y[2])*(pp[3]^y[3]) *
           (1-sum(pp))^r * gamma(sum(y)+r)/(prod(gamma(y+1))*gamma(r))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(pp[1]^y[i,1])*(pp[2]^y[i,2])*(pp[3]^y[i,3]) *
           (1-sum(pp))^r * gamma(sum(y[i,])+r)/(prod(gamma(y[i,]+1))*gamma(r))
  }
 }
  return(fout)
}
sum(fmnb(yy,c(.2,.15,.1)))
########################sample
rmnb=function(n,y,pp)
{
 ffmnb=c()
 for(i in 1:((k+1)^m))
 {
  ffmnb[i]=fmnb(y[i,],c(pp[1],pp[2],pp[3]))
 }
 ind=sample(1:((k+1)^m),size=n,prob=ffmnb,replace=TRUE)
 return(y[ind,])
}

####################Inflation in diagonal
#########################################


rmzkinb=function(n,p,pp)
{
  out= matrix(0,n,3)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3), size=1, prob=p)
    if(ran==0) out[i,]=c(0,0,0)
    else if(ran==1) out[i,]=c(1,1,1)
    else if(ran==2) out[i,]=c(2,2,2)
    else if(ran==3) out[i,]=rmnb(1,yy,pp)
   }
 return(out)
}

############################################ MLE
################################################

####################### initial parameter
alpha=0.05
###### With respect to H_0: 0 & H_1: c(0.01,0.05,0.1)
w3_0=0
par1=c(.3,.3,w3_0)

pp=c(.2,.15,.1)

Par=c(par1,1-sum(par1))
nn=length(c(par1,pp))
n=500
M=1000
ii=0

############################ SIM
emp_l=pow_l=p_v=t=c()
 oute=matrix(0,M,6)
 oute0=matrix(0,M,5)
 for(i in 1:M)
 {
  y=rmzkinb(n,Par,pp)
#####################################
lmzkinb <- function(par) {
   d=rep(0,n)
   ww=(1-(par[1]+par[2]+par[3]))
   for(i in 1:n)
   {
    if(identical(y[i,], c(0,0,0))) d[i]=par[1]
    else if(identical(y[i,], c(1,1,1))) d[i]=par[2]
    else if(identical(y[i,], c(2,2,2))) d[i]=par[3]
    d[i]=ww * fmnb(y[i,],c(par[4],par[5],par[6]))+d[i]
   }
   return(-sum(log(d)))
}
#lmzkinb(c(Par[1:3],pp))
 c_i=c(-1,-1,0,0,0,0,0,0)
  u_i=rbind(c(-1,-1,-1,0,0,0),c(0,0,0,-1,-1,-1),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
            c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
  init=c(.01,.01,.01,.2,.2,.2)
  out=constrOptim(init, lmzkinb, NULL, ui=u_i, ci=c_i)
     oute[i,]=c(out$par)
#####################################H_0
  lmzkinb0 <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]))
     for(i in 1:n)
     {
      if(identical(y[i,], c(0,0,0))) d[i]=par[1]
      else if(identical(y[i,], c(1,1,1))) d[i]=par[2]
      else if(identical(y[i,], c(2,2,2))) d[i]=0
      d[i]=ww * fmnb(y[i,],c(par[3],par[4],par[5]))+d[i]
     }
     return(-sum(log(d)))
    }

    c_i=c(-1,-1,0,0,0,0,0)
    u_i=rbind(c(-1,-1,0,0,0),c(0,0,-1,-1,-1),c(1,0,0,0,0),c(0,1,0,0,0),
            c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
     init=c(.01,.01,.1,.1,.1)
     out0=constrOptim(init, lmzkinb0, NULL, ui=u_i, ci=c_i)
     oute0[i,]=c(out0$par)
#####################################
  t[i]=2*(lmzkinb0(out0$par)-lmzkinb(out$par))
  p_v[i]=(0.5*pchisq(t[i], 1, lower.tail = FALSE)) 

  ii=ii+1
  if((ii%%10)==0) print(i)
  
 }
r=0
for(i in 1:M)
{
 if(p_v[i]<alpha) r=r+1
}
r/M
