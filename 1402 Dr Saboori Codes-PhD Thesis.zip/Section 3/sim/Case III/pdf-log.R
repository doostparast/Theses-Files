rm(list=ls(all=TRUE))
library(gtools)

k=12
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
yy=yy[-1,]
fmlog=function(y,pp)
{
 if(!(is.matrix(y)))
 {
  fout=(pp[1]^y[1])*(pp[2]^y[2])*(pp[3]^y[3])*gamma(sum(y))/
        (prod(gamma(y+1))*(-log(1-sum(pp))))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(pp[1]^y[i,1])*(pp[2]^y[i,2])*(pp[3]^y[i,3])*gamma(sum(y[i,]))/
         (prod(gamma(y[i,]+1))*(-log(1-sum(pp))))
  }
 }
  return(fout)
}
sum(fmlog(yy,c(.2,.15,.1)))

########################sample
rmlog=function(n,y,pp)
{
 ffmlog=c()
 for(i in 1:((k+1)^m-1))
 {
  ffmlog[i]=fmlog(y[i,],c(pp[1],pp[2],pp[3]))
 }
 ind=sample(1:((k+1)^m-1),size=n,prob=ffmlog,replace=TRUE)
 return(y[ind,])
}

####################Inflation in diagonal
#########################################


rmzkilog=function(n,p,pp)
{
  out= matrix(0,n,3)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3), size=1, prob=p)
    if(ran==0) out[i,]=c(2,0,0)
    else if(ran==1) out[i,]=c(0,2,0)
    else if(ran==2) out[i,]=c(0,0,2)
    else if(ran==3) out[i,]=rmlog(1,yy,pp)
   }
 return(out)
}

############################################ MLE
################################################

####################### initial parameter

par1=c(.15,.1,.05)
pp=c(.2,.15,.1)

Par=c(par1,1-sum(par1))
nn=length(c(par1,pp))
n=50
M=1000
ii=0
MSE=function(x) mean(x^2)
 oute=outb=matrix(0,M,6)

for(i in 1:M)
{
 y=rmzkilog(n,Par,pp)
 lmzkilog <- function(par) {
   d=rep(0,n)
   ww=(1-(par[1]+par[2]+par[3]))
   for(i in 1:n)
   {
         if(identical(y[i,], c(2,0,0))) d[i]=par[1]
    else if(identical(y[i,], c(0,2,0))) d[i]=par[2]
    else if(identical(y[i,], c(0,0,2))) d[i]=par[3]
    d[i]=ww * fmlog(y[i,],c(par[4],par[5],par[6]))+d[i]
   }
   return(-sum(log(d)))
}
#lmzkilog(c(Par[1:2],pp))
 c_i=c(-1,-1,0,0,0,0,0,0)
  u_i=rbind(c(-1,-1,-1,0,0,0),c(0,0,0,-1,-1,-1),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
    c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
  init=c(.01,.01,.01,.01,.01,.01)
  out=constrOptim(init, lmzkilog, NULL, ui=u_i, ci=c_i)
 ii=ii+1
 if((ii%%10)==0) print(i)
     oute[i,]=c(out$par)
     outb[i,]=(c(out$par)-c(par1,pp))
}
 par_e=round(apply(oute, 2, mean),4)
 par_b=round(apply(outb, 2, mean),4)
 par_mse=round(apply(outb, 2, MSE),4)


write(c(par_e[1],par_b[1],par_mse[1]),'d:\\sim\\log\\50\\par1.txt',append = T, sep = "   &  ",ncolumns = if(is.character(x)) 1 else 10)
write(c(par_e[2],par_b[2],par_mse[2]),'d:\\sim\\log\\50\\par2.txt',append = T, sep = "   &  ",ncolumns = if(is.character(x)) 1 else 10)
write(c(par_e[3],par_b[3],par_mse[3]),'d:\\sim\\log\\50\\par3.txt',append = T, sep = "   &  ",ncolumns = if(is.character(x)) 1 else 10)
write(c(par_e[4],par_b[4],par_mse[4]),'d:\\sim\\log\\50\\par4.txt',append = T, sep = "   &  ",ncolumns = if(is.character(x)) 1 else 10)
write(c(par_e[5],par_b[5],par_mse[5]),'d:\\sim\\log\\50\\par5.txt',append = T, sep = "   &  ",ncolumns = if(is.character(x)) 1 else 10)
write(c(par_e[6],par_b[6],par_mse[6]),'d:\\sim\\log\\50\\par6.txt',append = T, sep = "   &  ",ncolumns = if(is.character(x)) 1 else 10)

