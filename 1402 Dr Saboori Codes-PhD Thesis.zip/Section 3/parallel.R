rm(list=ls(all=TRUE))
library(gtools)

k=15
x=0:k
m=3
yy=permutations(n=(k+1),r=m,v=x,repeats.allowed=T)
fmp=function(y,la)
{
 if(!(is.matrix(y)))
 {
  fout=(dpois(y[1],la[1])*dpois(y[2],la[2])*dpois(y[3],la[3]))
 }
 else if(is.matrix(y))
 {
  fout=c()
   nr=nrow(y)
  for(i in 1:nr)
  {
  
   fout[i]=(dpois(y[i,1],la[1])*dpois(y[i,2],la[2])*dpois(y[i,3],la[3]))
  }
 }
  return(fout)
}
sum(fmp(yy,c(1.5,1,.5)))
########################sample
rmp=function(n,y,la)
{
 ffmp=c()
 for(i in 1:((k+1)^m))
 {
  ffmp[i]=fmp(y[i,],c(la[1],la[2],la[3]))
 }
 ind=sample(1:((k+1)^m),size=n,prob=ffmp,replace=TRUE)
 return(y[ind,])
}
####################Inflation in diagonal
#########################################


rmzkip1=function(n,p,la)
{
  out= matrix(0,n,3)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3), size=1, prob=p)
    if(ran==0) out[i,]=c(0,0,0)
    else if(ran==1) out[i,]=c(1,1,1)
    else if(ran==2) out[i,]=c(2,2,2)
    else if(ran==3) out[i,]=rmp(1,yy,la)
   }
 return(out)
}
lmzkip <- function(par) {
     d=rep(0,n)
     ww=(1-(par[1]+par[2]+par[3]))
     for(i in 1:n)
     {
      if(identical(y[i,], c(0,0,0))) d[i]=par[1]
      else if(identical(y[i,], c(1,1,1))) d[i]=par[2]
      else if(identical(y[i,], c(2,2,2))) d[i]=par[3]
      d[i]=ww * fmp(y[i,],c(par[4],par[5],par[6]))+d[i]
     }
     return(-sum(log(d)))
    }
 #lmzkip(c(Par[1:3],la))
    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)


library(foreach)
library(doParallel)
library(parallel)
par1=c(.15,.1,.05)
la=c(1.5,1,.5)

Par=c(par1,1-sum(par1))
nn=length(c(par1,la))

n=20
M=20

f=function(y){
    c_i=c(-1,0,0,0,0,0,0)
    u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0),
     c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
     init=c(.01,.01,.01,1,1,1)
  out=constrOptim(init, lmzkip, NULL, ui=u_i, ci=c_i)
  return(out$par)
}
  y=rmzkip1(n,Par,la)
f(y)

A<- matrix(0,M,6)
registerDoParallel(makeCluster(detectCores()))
A<-foreach(j=1:M,.combine='rbind') %dopar% f(y[j,]) *
stopImplicitCluster()
stopCluster(makeCluster(detectCores()))
