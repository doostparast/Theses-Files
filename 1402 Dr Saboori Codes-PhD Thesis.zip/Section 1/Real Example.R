fish=read.csv('d://fish.csv')
counts <- table(fish$count)
barplot(counts, main="Example 1",xlab="Number fish")

y6=c(rep(0,1884),rep(1,1417),rep(2,1362),rep(3,1536),rep(4,1115),
rep(5,905),rep(6,3504),rep(7,291))

barplot(table(y6), main="pap smear data 1",xlab="")

y0_1=c(rep(0,10046),rep(1,1466),rep(2,302),rep(3,246),rep(4,47),
rep(5,45),rep(6,25),rep(7,17),rep(8,7),rep(9,5),rep(10,6),
rep(11,4),rep(12,3),rep(13,9))

barplot(table(y0_1), main="ER data 1",xlab="")