rm(list=ls(all=TRUE))

#y=rnbinom(10000, size = 5, prob = 0.5) 
#y=rpois(1000,5)

y=rbinom(10000, 1, 0.5)
##############################################
################################### ESTIMATION

################################## POISSON
lfpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  -sum(log(dp))
}


 outp=optimize(lfpois,c(0,100))

################################## NB
lfnb=function(par) {
  dnb <- dnbinom(y, size = 1, prob = par)           
  -sum(log(dnb))
}


 outnb=optimize(lfnb,c(0,1))

################################## bin
lfb=function(par) {
  db <- dbinom(y, size = 1, prob = par)           
  -sum(log(db))
}


 outb=optimize(lfb,c(0,1))

################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)
################################## k=1
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,0),c(1,0,0),c(0,1,0),c(0,0,1))
 init=c(.1,.1,.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

################################## k=2


lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),c(0,0,0,1))
 init=c(.1,.1,.1,.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

################################## k=3

lpmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  -sum(log(d3))
}


 c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0),c(1,0,0,0,0),c(0,1,0,0,0),
c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)
################################## k=4

lpmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  -sum(log(d4))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1)
 out4=constrOptim(init, lpmf4, NULL, ui=u_i, ci=c_i)
################################## k=5

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0),
c(0,1,0,0,0,0,0),c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0),
c(0,0,0,0,1,0,0),c(0,0,0,0,0,1,0),c(0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)

outp$objective
outnb$objective
outb$objective

out0$value
out1$value
out2$value
out3$value
out4$value
out5$value

