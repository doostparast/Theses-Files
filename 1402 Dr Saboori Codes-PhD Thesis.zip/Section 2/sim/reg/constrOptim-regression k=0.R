rm(list=ls(all=TRUE))

#######################################PMF k=0

rzkip <- function(n,par) {
  p=c(par[1],(1-(par[1])))
  outt=rep(0,n)
  for(i in 1:n)
   {
    ran=sample(c(0,1), size=1, prob=p)
    if(ran==0) outt[i]=0
    else if(ran==1) outt[i]=rpois(1,(exp(par[2]+par[3]*x1[i]+par[4]*x2[i])))
   }
return(outt)
}
##############################################
################################### SIMILATION
 m=10000
 nn=1000
 b0=.5
 b1=-.5
 b2=-.5
foute=matrix(0,m,4)
foutb=matrix(0,m,4)

lpmf <- function(par) {
  d <- (par[1] * (y == 0)+(1-(par[1]))*
        dpois(y,(exp(par[2]+par[3]*x1+par[4]*x2))))           
  -sum(log(d))
}
  x1=rnorm(nn)
  x2=rbinom(nn,1,.5)

  Par=c(.2,b0,b1,b2)
ii=0
for(i in 1:m)
{
 y=rzkip(nn, Par)
 #print(table(y))

 c_i=c(-1,0)
 u_i=rbind(c(-1,0,0,0),c(1,0,0,0))
 init=c(.2,.1,-.1,-.1)
 out=constrOptim(init, lpmf, NULL, ui=u_i, ci=c_i)

 foute[i,]=c(out$par)
 foutb[i,]=(out$par-Par)
write(c(out$par[1]),'d:\\w0.txt',append = T)
write(c(out$par[2]),'d:\\b0.txt',append = T)
write(c(out$par[3]),'d:\\b1.txt',append = T)
write(c(out$par[4]),'d:\\b2.txt',append = T)
write(c(out$value),'d:\\value.txt',append = T)
 ii=ii+1
 if((ii%%50)==0) print(c(i,out$par))
}

#w0
mean(c(foute[,1]))


#b0
mean(c(foute[,2]))

#b1
mean(c(foute[,3]))

#b2
mean(c(foute[,4]))

############################## SE
#w0
round(sqrt(var(c(foute[,1]))/m),4)

#b0
round(sqrt(var(c(foute[,2]))/m),4)

#b1
round(sqrt(var(c(foute[,3]))/m),4)

#b2
round(sqrt(var(c(foute[,4]))/m),4)


####################################################
####################################################
outf0=scan(file="d:\\w0.txt")
outfb0=scan(file="d:\\b0.txt")
outfb1=scan(file="d:\\b1.txt")
outfb2=scan(file="d:\\b2.txt")
outfvalue=scan(file="d:\\value.txt")

round(mean(outf0),4)
round(mean(outfb0),4)
round(mean(outfb1),4)
round(mean(outfb2),4)
round(mean(outfvalue),4)

round(sqrt(var(outf0)/m),4)

round(sqrt(var(outfb0)/m),4)

round(sqrt(var(outfb1)/m),4)

round(sqrt(var(outfb2)/m),4)




