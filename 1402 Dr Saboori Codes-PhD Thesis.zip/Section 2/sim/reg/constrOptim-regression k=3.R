rm(list=ls(all=TRUE))

#######################################PMF k=3

rzkip <- function(n,par) {
  p=c(par[1],par[2],par[3],par[4],(1-(par[1]+par[2]+par[3]+par[4])))
  outt=rep(0,n)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3,4), size=1, prob=p)
    if(ran==0) outt[i]=0
    else if(ran==1) outt[i]=1
    else if(ran==2) outt[i]=2
    else if(ran==3) outt[i]=3
    else if(ran==4) outt[i]=rpois(1,(exp(par[5]+par[6]*x1[i]+par[7]*x2[i])))
   }
return(outt)
}
##############################################
################################### SIMILATION
 m=10000
 nn=1000
 b0=.05
 b1=.05
 b2=-.05
foute=matrix(0,m,7)
foutb=matrix(0,m,7)

lpmf <- function(par) {
  d <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) + 
        par[4] * (y == 3) + (1-(par[1]+par[2]+par[3]+par[4])) *
        dpois(y,(exp(par[5]+par[6]*x1+par[7]*x2))))           
  -sum(log(d))
}
  x1=rnorm(nn)
  x2=rbinom(nn,1,.5)

  Par=c(.2,.2,.2,.2,b0,b1,b2)
ii=0
for(i in 1:m)
{
 y=rzkip(nn, Par)
 #print(table(y))

 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0),c(0,1,0,0,0,0,0),
c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0))
 init=c(.2,.2,.2,.2,.1,-.1,-.1)
 out=constrOptim(init, lpmf, NULL, ui=u_i, ci=c_i)

 foute[i,]=c(out$par)
 foutb[i,]=(out$par-Par)

 ii=ii+1
 if((ii%%50)==0) print(c(i,out$par))
}

#w0
mean(c(foutb[,1]))

#w1
mean(c(foutb[,2]))

#w2
mean(c(foutb[,3]))

#w3
mean(c(foutb[,4]))

#b0
mean(c(foutb[,5]))

#b1
mean(c(foutb[,6]))

#b2
mean(c(foutb[,7]))

############################## SE
#w0
round(sqrt(var(c(foute[,1]))/m),4)

#w1
round(sqrt(var(c(foute[,2]))/m),4)

#w2
round(sqrt(var(c(foute[,3]))/m),4)

#w3
round(sqrt(var(c(foute[,4]))/m),4)

#b0
round(sqrt(var(c(foute[,5]))/m),4)

#b1
round(sqrt(var(c(foute[,6]))/m),4)

#b2
round(sqrt(var(c(foute[,7]))/m),4)






