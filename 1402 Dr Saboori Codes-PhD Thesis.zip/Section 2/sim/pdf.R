######################################### plot pmf
##################################################

###################### ZIP

pmf <- function(x,la,w,k)
{
  ff=0
  if(x<=k)
   {
    for(i in 0:k)
     {
      if(x==i)
      {ff=(w[(i+1)]+w[k+2]*dpois(i,la))}
     }
      }
    if(x>k)
     {ff=(w[k+2]*dpois(x,la))}
return(ff) 
}
x=0:10
y=c()
for(i in 1:length(x))y[i]=pmf(x[i],1,c(0.5,0.5),0)

par( mfrow = c(2 ,2))

plot (x = x , y = y , type = "h", xlab = "x", ylab =
"g(x)", main = " ZIP" ,
panel.first = grid (col="gray", lty = "dotted") , lwd = 3)
abline(h = 0)
legend(6.5,0.69,c(
expression(paste(plain(lambda*"=1"))),
expression(paste(plain(w0*"=0.5")))
),text.width=2.5)

###################### ZOIP

x=0:10
y=c()
for(i in 1:length(x))y[i]=pmf(x[i],1,c(0.4,0.3,0.3),1)

plot (x = x , y = y , type = "h", xlab = "x", ylab =
"g(x)", main = " ZOIP" ,
panel.first = grid (col="gray", lty = "dotted") , lwd = 3)
abline(h = 0)
legend(6.5,0.52,c(
expression(paste(plain(lambda*"=1"))),
expression(paste(plain(w0*"=0.4"))),
expression(paste(plain(w1*"=0.3")))
),text.width=2.5)

###################### ZOTIP

x=0:10
y=c()
for(i in 1:length(x))y[i]=pmf(x[i],1,c(0.3,0.3,0.2,0.2),2)

plot (x = x , y = y , type = "h", xlab = "x", ylab =
"g(x)", main = " ZOTIP" ,
panel.first = grid (col="gray", lty = "dotted") , lwd = 3)
abline(h = 0)
legend(6.5,0.38,c(
expression(paste(plain(lambda*"=1"))),
expression(paste(plain(w0*"=0.3"))),
expression(paste(plain(w1*"=0.3"))),
expression(paste(plain(w2*"=0.2")))
),text.width=2.5)

###################### ZOTTIP

x=0:10
y=c()
for(i in 1:length(x))y[i]=pmf(x[i],1,c(0,.4,0,0.4,0.2),3)

plot (x = x , y = y , type = "h", xlab = "x", ylab =
"g(x)", main = " ZOTTIP" ,
panel.first = grid (col="gray", lty = "dotted") , lwd = 3)
abline(h = 0)
legend(6.15,0.48,c(
expression(paste(plain(lambda*"=1"))),
expression(paste(plain(w0*"=0"))),
expression(paste(plain(w1*"=0.4"))),
expression(paste(plain(w1*"=0"))),
expression(paste(plain(w3*"=0.4")))
),text.width=2.8)

