rm(list=ls(all=TRUE))

#######################################PMF k=3

rzkip <- function(n,par) {
  p=c(par[1],par[2],par[3],par[4],(1-(par[1]+par[2]+par[3]+par[4])))
  outt=rep(0,n)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3,4), size=1, prob=p)
    if(ran==0) outt[i]=0
    else if(ran==1) outt[i]=1
    else if(ran==2) outt[i]=2
    else if(ran==3) outt[i]=3
    else if(ran==4) outt[i]=rpois(1,(exp(par[5]+par[6]*x1[i]+par[7]*x2[i])))
   }
return(outt)
}
##############################################
################################### SIMILATION
 nn=500
 b0=.5
 b1=-.5
 b2=-.5
  x1=rnorm(nn)
  x2=rbinom(nn,1,.5)

  Par=c(.2,.2,.2,.2,b0,b1,b2)

 la=exp(Par[4]+Par[5]*x1+Par[6])
 Par=c(c(.15,.15,.15,.15),la)
 y=z=x=rzkip(nn,Par)
table(x)
m=length(table(z))
o=c(table(y)[1:8],sum(table(y)[9:m]))
x=0:(m-1)

o
###############################################################POISSON
lfpois=function(par) {
  lap=exp(par[1]+par[2]*x1+par[3]*x2)
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 init=c(0,0,.0)
 outp=optim(init, lfpois)

fpois=function(par,y) {
  lap=exp(par[1]+par[2]*x1+par[3]*x2)
  dp <- dpois(y,lap)           
  dp
}

logp=lfpois(outp$par)
###################################################################k=0
lpmf0 <- function(par) {
  d0 <- (par[1] * (y == 0) + 
        (1-(par[1]))*dpois(y,(exp(par[2]+par[3]*x1+par[4]*x2))))           
  -sum(log(d0))
}

 c_i=c(-1,0)
 u_i=rbind(c(-1,0,0,0),c(1,0,0,0))
 init=c(.2,.1,-.1,-.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)


pmf0 <- function(par,y) {
  d0 <- (par[1] * (y == 0) + 
         (1-(par[1]))*dpois(y,(exp(par[2]+par[3]*x1+par[4]*x2))))           
  d0
}

log0=lpmf0(out0$par)


###################################################################k=1
y=z
lpmf1 <- function(par) {
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1) + 
        (1-(par[1]+par[2]))*dpois(y,(exp(par[3]+par[4]*x1+par[5]*x2))))           
  -sum(log(d1))
}

 c_i=c(-1,0,0)
 u_i=rbind(c(-1,-1,0,0,0),c(1,0,0,0,0),c(0,1,0,0,0))
 init=c(.2,.2,.1,-.1,-.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

pmf1 <- function(par,y) {
  d1 <- (par[1] * (y == 0) +
         (1-(par[1]))*dpois(y,(exp(par[2]+par[3]*x1+par[4]*x2))))           
  d1
}

log1=lpmf1(out1$par)

###################################################################k=2
y=z
lpmf2 <- function(par) {
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) + 
        (1-(par[1]+par[2]+par[3]))*dpois(y,(exp(par[4]+par[5]*x1+par[6]*x2))))           
  -sum(log(d2))
}

 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
c(0,0,1,0,0,0))
 init=c(.2,.2,.2,.1,-.1,-.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

pmf2 <- function(par,y) {
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) + 
         (1-(par[1]+par[2]+par[3]))*dpois(y,(exp(par[4]+par[5]*x1+par[6]*x2))))           
  d2
}

log2=lpmf2(out2$par)

###################################################################k=3
y=z
lpmf3 <- function(par) {
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) + 
        par[4] * (y == 3) + (1-(par[1]+par[2]+par[3]+par[4])) *
        dpois(y,(exp(par[5]+par[6]*x1+par[7]*x2))))           
  -sum(log(d3))
}

 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0),c(0,1,0,0,0,0,0),
c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0))
 init=c(.2,.2,.2,.2,.1,-.1,-.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)


pmf3 <- function(par,y) {
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) + 
        par[4] * (y == 3) + (1-(par[1]+par[2]+par[3]+par[4])) *
        dpois(y,(exp(par[5]+par[6]*x1+par[7]*x2))))           
  d3
}
log3=lpmf3(out3$par)

#####################################################KI2 and ABE
################################################################

#######################################################k=3
ee3=c()
for(i in 0:m){
ee3[i+1]=mean(pmf3(out3$par,i)*nn)
}
e3=c(ee3[1:8],sum(ee3[9:m]))
round(e3,2)

ABE3=sum(abs(o-e3))
round(ABE3,4)

KI3=sum(((o-e3)^2)/e3)
round(KI3,4)

log3

#######################################################k=2
ee2=c()
for(i in 0:m){
ee2[i+1]=mean(pmf2(out2$par,i)*nn)
}
e2=c(ee2[1:8],sum(ee2[9:m]))
round(e2,2)

ABE2=sum(abs(o-e2))
round(ABE2,4)

KI2=sum(((o-e2)^2)/e2)
round(KI2,4)

log2

#######################################################k=1
ee1=c()
for(i in 0:m){
ee1[i+1]=mean(pmf1(out1$par,i)*nn)
}
e1=c(ee1[1:8],sum(ee1[9:m]))
round(e1,2)

ABE1=sum(abs(o-e1))
round(ABE1,4)

KI1=sum(((o-e1)^2)/e1)
round(KI1,4)

log1

#######################################################k=0
ee0=c()
for(i in 0:m){
ee0[i+1]=mean(pmf0(out0$par,i)*nn)
}
e0=c(ee0[1:8],sum(ee0[9:m]))
round(e0,2)

ABE0=sum(abs(o-e0))
round(ABE0,4)

KI0=sum(((o-e0)^2)/e0)
round(KI0,4)

log0

#################################################POISSON
eep=c()
for(i in 0:m){
eep[i+1]=mean(fpois(outp$par,i)*nn)
}
ep=c(eep[1:8],sum(eep[9:m]))
round(ep,2)

ABEp=sum(abs(o-ep))
round(ABEp,4)

KIp=sum(((o-ep)^2)/ep)
round(KIp,4)

logp
