rm(list=ls(all=TRUE))

#######################################PMF k=3

rzkip <- function(n,par) {
  p=c(par[-5],(1-sum(par[-5])))
  out=rep(0,n)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3,4), size=1, prob=p)
    if(ran==0) out[i]=0
    else if(ran==1) out[i]=1
    else if(ran==2) out[i]=2
    else if(ran==3) out[i]=3
    else if(ran==4) out[i]=rpois(1,par[5])
   }
return(out)
}
##############################################
################################### SIMILATION
 nn=20
 la=2
 Par=c(c(.15,.15,.15,.15),la)
 y=z=x=rzkip (nn, Par)
table(x)
m=length(table(z))
o=c(table(y))
x=0:(m-1)

##################################################POSSON
logp=-sum(log(dpois((z),(mean(z)))))

obsp1=(dpois((x),(mean(z)))*nn)
obsp=c(obsp1)
#obsp[is.na(obsp)]=0

round(obsp,2)
ABE=sum(abs(o-obsp))
round(ABE,4)

KI=sum(((o-obsp)^2)/obsp)
round(KI,4)


#####################################################k=0
lpmf0 <- function(par) {
  ww=(1-par[1])
  d <- par[1] * (y == 0) + ww * dpois(y, par[2])              
  -sum(log(d))
 }
y=z
c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,1)
 out=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)

pmf0 <- function(par) {
  ww=(1-par[1])
  d <- par[1] * (y == 0) + ww * dpois(y, par[2])              
  d
 }
y=z
log0=lpmf0(out$par)
y=x
e1=(pmf0(out$par)*nn)
e=c(e1)

round(e,2)
ABE=sum(abs(o-e))
round(ABE,4)

KI=sum(((o-e)^2)/e)
round(KI,4)
#####################################################k=1
lpmf1 <- function(par) {
  ww=(1-(par[1]+par[2]))
  d <- par[1] * (y == 0) +par[2] * (y == 1) + ww * dpois(y, par[3])              
  -sum(log(d))
 }
y=z
c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,0),c(1,0,0),c(0,1,0),c(0,0,1))
 init=c(.1,.1,1)
 out=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

pmf1 <- function(par) {
  ww=(1-(par[1]+par[2]))
  d <- par[1] * (y == 0) +par[2] * (y == 1) + ww * dpois(y, par[3])              
  d
 }
y=z
log1=lpmf1(out$par)
y=x

e1=(pmf1(out$par)*nn)
e=c(e1 )

round(e,2)
ABE=sum(abs(o-e))
round(ABE,4)

KI=sum(((o-e)^2)/e)
round(KI,4)
#####################################################k=2
lpmf2 <- function(par) {
  ww=(1-(par[1]+par[2]+par[3]))
  d <- par[1] * (y == 0) +par[2] * (y == 1) +par[3] * (y == 2) +
       ww * dpois(y, par[4])              
  -sum(log(d))
 }
y=z
c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),
   c(0,0,0,1))
 init=c(.1,.1,.1,1)
 out=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

pmf2 <- function(par) {
  ww=(1-(par[1]+par[2]+par[3]))
  d <- par[1] * (y == 0) +par[2] * (y == 1) +par[3] * (y == 2) +
       ww * dpois(y, par[4])              
  d
 }
y=z
log2=lpmf2(out$par)
y=x

e1=(pmf2(out$par)*nn)
e=c(e1 )

round(e,2)
ABE=sum(abs(o-e))
round(ABE,4)

KI=sum(((o-e)^2)/e)
round(KI,4)

#####################################################k=3
lpmf3 <- function(par) {
  ww=(1-(par[1]+par[2]+par[3]+par[4]))
  d <- par[1] * (y == 0) +par[2] * (y == 1) +par[3] * (y == 2) +
       par[4] * (y == 3)+ ww * dpois(y, par[5])              
  -sum(log(d))
 }
y=z
c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0),c(1,0,0,0,0),c(0,1,0,0,0),c(0,0,1,0,0),
   c(0,0,0,1,0),c(0,0,0,0,1))
 init=c(.1,.1,.1,.1,1)
 out=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)

pmf3 <- function(par) {
  ww=(1-(par[1]+par[2]+par[3]+par[4]))
  d <- par[1] * (y == 0) +par[2] * (y == 1) +par[3] * (y == 2) +
       par[4] * (y == 3)+ ww * dpois(y, par[5])              
  d
}
y=z
log3=lpmf3(out$par)
y=x


e1=(pmf3(out$par)*nn)
e=c(e1)

round(e,2)
ABE=sum(abs(o-e))
round(ABE,4)

KI=sum(((o-e)^2)/e)
round(KI,4)

logp
log0
log1
log2
log3

