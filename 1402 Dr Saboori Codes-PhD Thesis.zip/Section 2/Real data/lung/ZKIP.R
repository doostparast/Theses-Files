rm(list=ls(all=TRUE))
library(survival)
data(lung)
#help(lung)
library(data.table)
xx=lung
  yy=y=nafill(xx$ph.ecog, "locf")

  x1=xx$age
  x2=xx$sex

##############################################
################################### ESTIMATION

################################## POISSON
lfpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 init=c(.1)
 outp=optim(init, lfpois)
################################## NB
lfnb=function(par) {
  pnb=par
  dnb <- dnbinom(y,1,pnb)           
  -sum(log(dnb))
}

 init=c(.1)
 outnb=optim(init, lfnb)
################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)

################################## k=1
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,0),c(1,0,0),c(0,1,0),c(0,0,1))
 init=c(.1,.1,.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

################################## k=2


lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),c(0,0,0,1))
 init=c(.1,.1,.1,.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

################################## k=3

lpmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  -sum(log(d3))
}


 c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0),c(1,0,0,0,0),c(0,1,0,0,0),
c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)
################################## k=4

lpmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  -sum(log(d4))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1)
 out4=constrOptim(init, lpmf4, NULL, ui=u_i, ci=c_i)
################################## k=5

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0),
c(0,1,0,0,0,0,0),c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0),
c(0,0,0,0,1,0,0),c(0,0,0,0,0,1,0),c(0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)
################################## k=6

lpmf6 <- function(par) {
  ww6=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7])
  la6=par[8]
  d6 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5) + 
 par[7] * (y == 6)+ ww6 * dpois(y,la6))            
  -sum(log(d6))
}


 c_i=c(-1,0,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0),c(0,0,0,1,0,0,0,0),
c(0,0,0,0,1,0,0,0),c(0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1,.1)
 out6=constrOptim(init, lpmf6, NULL, ui=u_i, ci=c_i)
################################## k=7

lpmf7 <- function(par) {
  ww7=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7]++par[8])
  la7=par[9]
  d7 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5) + 
 par[7] * (y == 6) +  par[8] * (y == 7) + ww7 * dpois(y,la7))            
  -sum(log(d7))
}


 c_i=c(-1,0,0,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0),c(0,0,0,1,0,0,0,0,0),
c(0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,1,0,0,0),c(0,0,0,0,0,0,1,0,0),
c(0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1,.1,.1)
 out7=constrOptim(init, lpmf7, NULL, ui=u_i, ci=c_i)
################################## k=8

lpmf8 <- function(par) {
  ww8=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7]+par[8]+par[9])
  la8=par[10]
  d8 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5) + 
 par[7] * (y == 6) +  par[8] * (y == 7) +  par[9] * (y == 8) +
 ww8 * dpois(y,la8))            
  -sum(log(d8))
}


 c_i=c(-1,0,0,0,0,0,0,0,0,0,0)
 u_i=rbind(
c(-1,-1,-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0),
c(0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1,.1,.1,.1)
 out8=constrOptim(init, lpmf8, NULL, ui=u_i, ci=c_i)
################################## k=9

lpmf9 <- function(par) {
  ww9=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7]+par[8]+par[9]+
      par[10])
  la9=par[11]
  d9 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5) + 
 par[7] * (y == 6) +  par[8] * (y == 7) +  par[9] * (y == 8) +
 par[10] * (y == 9) + ww9 * dpois(y,la9))            
  -sum(log(d9))
}


 c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0)
 u_i=rbind(
c(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0),
c(0,0,0,0,0,0,0,1,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0),
c(0,0,0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,0,0,1))
 init=c(.01,.01,.01,.01,.01,.01,.01,.01,.01,.01,.1)
 out9=constrOptim(init, lpmf9, NULL, ui=u_i, ci=c_i)
################################## k=10

lpmf10 <- function(par) {
  ww10=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7]+par[8]+par[9]+
      par[10]+par[11])
  la10=par[12]
  d10 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5) + 
 par[7] * (y == 6) +  par[8] * (y == 7) +  par[9] * (y == 8) +
 par[10] * (y == 9)+ par[11] * (y == 10) + ww10 * dpois(y,la10))            
  -sum(log(d10))
}


 c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0)
 u_i=rbind(
c(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0),
c(0,0,0,0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0),
c(0,0,0,0,0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0),
c(0,0,0,0,0,0,0,0,0,0,0,1))
 init=c(.01,.01,.01,.01,.01,.01,.01,.01,.01,.01,.01,.1)
 out10=constrOptim(init, lpmf10, NULL, ui=u_i, ci=c_i)

################################## k=11

lpmf11 <- function(par) {
  ww11=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7]+par[8]+par[9]+
      par[10]+par[11]+par[12])
  la11=par[13]
  d11 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5) + 
 par[7] * (y == 6) +  par[8] * (y == 7) +  par[9] * (y == 8) +
 par[10] * (y == 9)+ par[11] * (y == 10) +
+ par[12] * (y == 11) + ww11 * dpois(y,la11))            
  -sum(log(d11))
}


 c_i=c(-1,0,0,0,0,0,0,0,0,0,0,0,0,0)
 u_i=rbind(
c(-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0,0,0,0,0),
c(0,0,0,1,0,0,0,0,0,0,0,0,0),c(0,0,0,0,1,0,0,0,0,0,0,0,0),
c(0,0,0,0,0,1,0,0,0,0,0,0,0),c(0,0,0,0,0,0,1,0,0,0,0,0,0),
c(0,0,0,0,0,0,0,1,0,0,0,0,0),c(0,0,0,0,0,0,0,0,1,0,0,0,0),
c(0,0,0,0,0,0,0,0,0,1,0,0,0),c(0,0,0,0,0,0,0,0,0,0,1,0,0),
c(0,0,0,0,0,0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,0,0,0,0,0,1))
 init=c(.01,.01,.01,.01,.01,.01,.01,.01,.01,.01,.01,.01,.1)
 out11=constrOptim(init, lpmf11, NULL, ui=u_i, ci=c_i)


############################################
#################################### COMPARE
# AIC
z=c()
z[1]=2*1+2*outp$value
z[2]=2*1+2*outnb$value
z[3]=2*2+2*out0$value
z[4]=2*3+2*out1$value
z[5]=2*4+2*out2$value
z[6]=2*5+2*out3$value
z[7]=2*6+2*out4$value
z[8]=2*7+2*out5$value
z[9]=2*8+2*out6$value
z[10]=2*9+2*out7$value
z[11]=2*10+2*out8$value
z[12]=2*11+2*out9$value
z[13]=2*12+2*out10$value
z[14]=2*13+2*out11$value
k=(1:14)
plot(k,z,type='o')

#############################################
#############################################
n=length(yy)
nn=(length(table(yy)))
m=3

obs=c(table(yy)[1:(m)],sum(table(yy)[(m+1):nn]))
y=0:(nn-1)


################################## POISSON
fpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  dp
}

################################## NB
fnb=function(par) {
  pnb=par
  dnb <- dnbinom(y,1,pnb)           
  dnb
}

################################## k=0
pmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  d0
}


################################## k=1
pmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  d1
}



################################## k=2


pmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  d2
}


################################## k=3

pmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  d3
}

################################## k=4

pmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  d4
}
################################## k=4

pmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+
+ par[4] * (y == 5) + ww5 * dpois(y,la5))            
  d5
}
#####################################Expectaion of observation
round(fpois(outp$par)*n,2)
round(sum((fpois(outp$par)*n)[(m+1):nn]),2)

round(pmf0(out0$par)*n,2)
round(sum((pmf0(out0$par)*n)[(m+1):nn]),2)

round(pmf1(out1$par)*n,2)
round(sum((pmf1(out1$par)*n)[(m+1):nn]),2)

round(pmf2(out2$par)*n,2)
round(sum((pmf2(out2$par)*n)[(m+1):nn]),2)

round(pmf3(out3$par)*n,2)
round(sum((pmf3(out3$par)*n)[(m+1):nn]),2)

round(pmf4(out4$par)*n,2)
round(sum((pmf4(out4$par)*n)[(m+1):nn]),2)

round(pmf5(out5$par)*n,2)
round(sum((pmf5(out5$par)*n)[(m+1):nn]),2)

##########################################poisson
eep=(fpois(outp$par)*n)
ep=c(eep[1:(m)],sum(eep[(m+1):nn]))
ABEp=sum(abs(obs-ep))
kip=sum(((ep-obs)^2)/ep)
round(ABEp,2)
round(kip,2)
##########################################k=0
ee0=(pmf0(out0$par)*n)
e0=c(ee0[1:m],sum(ee0[(m+1):nn]))
ABE0=sum(abs(obs-e0))
ki0=sum(((e0-obs)^2)/e0)
round(ABE0,3)
round(ki0,3)
##########################################k=1
ee1=(pmf1(out1$par)*n)
e1=c(ee1[1:m],sum(ee1[(m+1):nn]))
ABE1=sum(abs(obs-e1))
ki1=sum(((e1-obs)^2)/e1)
round(ABE1,3)
round(ki1,3)
##########################################k=2
ee2=(pmf2(out2$par)*n)
e2=c(ee2[1:m],sum(ee2[(m+1):nn]))
ABE2=sum(abs(obs-e2))
ki2=sum(((e2-obs)^2)/e2)
round(ABE2,3)
round(ki2,3)
##########################################k=3
ee3=(pmf3(out3$par)*n)
e3=c(ee3[1:m],sum(ee3[(m+1):nn]))
ABE3=sum(abs(obs-e3))
ki3=sum(((e3-obs)^2)/e3)
round(ABE3,2)
round(ki3,2)
##########################################k=4
ee4=(pmf4(out4$par)*n)
e4=c(ee4[1:m],sum(ee4[(m+1):nn]))
ABE4=sum(abs(obs-e4))
ki4=sum(((e4-obs)^2)/e4)
round(ABE4,2)
round(ki4,2)
##########################################k=5
ee5=(pmf5(out5$par)*n)
e5=c(ee5[1:m],sum(ee5[(m+1):nn]))
ABE5=sum(abs(obs-e5))
ki5=sum(((e5-obs)^2)/e5)
round(ABE5,2)
round(ki5,2)
