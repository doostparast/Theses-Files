rm(list=ls(all=TRUE))
library(survival)
data(lung)
#help(lung)
library(data.table)
xx=lung
  x=z=yy=y=nafill(xx$ph.ecog, "locf")

  x1=rep(0,length(xx$age))
  x2=rep(0,length(xx$sex))

##############################################
################################### ESTIMATION

################################## POISSON
lfpois=function(par) {
  lap_1=exp(par[1]+par[2]*x1+par[3]*x2)
  lap=mean(lap_1)
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 init=c(0,0,.0)
 outp=optim(init, lfpois)
################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0_1=exp(par[2]+par[3]*x1+par[4]*x2)
  la0=mean(la0_1)
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0)
 u_i=rbind(c(-1,0,0,0),c(1,0,0,0))
 init=c(.2,.1,-.1,-.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)

################################## k=1
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1_1=exp(par[3]+par[4]*x1+par[5]*x2)
  la1=mean(la1_1)
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,-1,0,0,0),c(1,0,0,0,0),c(0,1,0,0,0))
 init=c(.2,.2,.1,-.1,-.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

################################## k=2


lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2_1=exp(par[4]+par[5]*x1+par[6]*x2)
  la2=mean(la2_1)
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,-1,0,0,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),c(0,0,1,0,0,0))
 init=c(.2,.2,.2,.1,-.1,-.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

################################## k=3

lpmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3_1=exp(par[5]+par[6]*x1+par[7]*x2)
  la3=mean(la3_1)
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  -sum(log(d3))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0),c(0,1,0,0,0,0,0),
c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0))
 init=c(.2,.2,.2,.2,.1,-.1,-.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)
################################## k=4

lpmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4_1=exp(par[6]+par[7]*x1+par[8]*x2)
  la4=mean(la4_1)
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  -sum(log(d4))
}


 c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0),c(0,1,0,0,0,0,0,0),
c(0,0,1,0,0,0,0,0),c(0,0,0,1,0,0,0,0),c(0,0,0,0,1,0,0,0))
 init=c(.1,.1,.1,.1,.1,.1,-.1,-.1)
 out4=constrOptim(init, lpmf4, NULL, ui=u_i, ci=c_i)
################################## k=5

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5_1=exp(par[7]+par[8]*x1+par[9]*x2)
  la5=mean(la5_1)
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0),c(0,0,0,1,0,0,0,0,0),
c(0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,1,0,0,0))
 init=c(.1,.1,.1,.1,.1,.1,.1,-.1,-.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)


#####################################################KI2 and ABE
################################################################
################################## POISSON
fpois=function(par,y) {
  lap_1=exp(par[1]+par[2]*x1+par[3]*x2)
  lap=mean(lap_1)
  dp <- dpois(y,lap)           
  dp
}


################################## k=0
pmf0 <- function(par,y) {
  ww0=(1-par[1])
  la0_1=exp(par[2]+par[3]*x1+par[4]*x2)
  la0=mean(la0_1)
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  d0
}


################################## k=1
pmf1 <- function(par,y) {
  ww1=(1-par[1]-par[2])
  la1_1=exp(par[3]+par[4]*x1+par[5]*x2)
  la1=mean(la1_1)
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  d1
}



################################## k=2


pmf2 <- function(par,y) {
  ww2=(1-par[1]-par[2]-par[3])
  la2_1=exp(par[4]+par[5]*x1+par[6]*x2)
  la2=mean(la2_1)
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  d2
}


################################## k=3

pmf3 <- function(par,y) {
  ww3=(1-par[1]-par[2]-par[3]-par[4])
  la3_1=exp(par[5]+par[6]*x1+par[7]*x2)
  la3=mean(la3_1)
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  d3
}

################################## k=4

pmf4 <- function(par,y) {
  ww4=(1-par[1]-par[2]-par[3]-par[4]-par[5])
  la4_1=exp(par[6]+par[7]*x1+par[8]*x2)
  la4=mean(la4_1)
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  d4
}
################################## k=5

pmf5 <- function(par,y) {
  ww5=(1-par[1]-par[2]-par[3]-par[4]-par[5]-par[6])
  la5_1=exp(par[7]+par[8]*x1+par[9]*x2)
  la5=mean(la5_1)
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+
+ par[6] * (y == 5) + ww5 * dpois(y,la5))            
  d5
}


 nn=length(y)

table(x)
m=length(table(z))
o=c(table(y)[1:m])
x=0:(m-1)
##########################################################

#######################################################k=5
e5=c()
for(i in 0:(m-1)){
e5[i+1]=(pmf5(out5$par,i)*nn)
}
round(e5,2)

ABE5=sum(abs(o-e5))
round(ABE5,5)

KI5=sum(((o-e5)^2)/e5)
round(KI5,5)

#######################################################k=4
e4=c()
for(i in 0:(m-1)){
e4[i+1]=(pmf4(out4$par,i)*nn)
}
round(e4,2)

ABE4=sum(abs(o-e4))
round(ABE4,4)

KI4=sum(((o-e4)^2)/e4)
round(KI4,4)

#######################################################k=3
e3=c()
for(i in 0:(m-1)){
e3[i+1]=(pmf3(out3$par,i)*nn)
}
round(e3,2)

ABE3=sum(abs(o-e3))
round(ABE3,4)

KI3=sum(((o-e3)^2)/e3)
round(KI3,4)


#######################################################k=2
e2=c()
for(i in 0:(m-1)){
e2[i+1]=(pmf2(out2$par,i)*nn)
}
round(e2,2)

ABE2=sum(abs(o-e2))
round(ABE2,4)

KI2=sum(((o-e2)^2)/e2)
round(KI2,4)


#######################################################k=1
e1=c()
for(i in 0:(m-1)){
e1[i+1]=(pmf1(out1$par,i)*nn)
}
round(e1,2)

ABE1=sum(abs(o-e1))
round(ABE1,4)

KI1=sum(((o-e1)^2)/e1)
round(KI1,4)


#######################################################k=0
e0=c()
for(i in 0:(m-1)){
e0[i+1]=(pmf0(out0$par,i)*nn)
}
round(e0,2)

ABE0=sum(abs(o-e0))
round(ABE0,4)

KI0=sum(((o-e0)^2)/e0)
round(KI0,4)


#################################################POISSON
ep=c()
for(i in 0:(m-1)){
ep[i+1]=(fpois(outp$par,i)*nn)
}
round(ep,2)

ABEp=sum(abs(o-ep))
round(ABEp,4)


