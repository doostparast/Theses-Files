rm(list=ls(all=TRUE))
xx <- read.table(file = "D:\\Data\\DeHartSimplified.csv",
header=TRUE , sep= ",", na.strings = " ")
y=xx$numall
y[is.na(y)]<-0
yy=y
##############################################
################################### ESTIMATION
##############################################
################################### ESTIMATION

################################## POISSON

lfpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 outp=optimize(lfpois,c(0,100))

################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)

################################## k=1
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,0),c(1,0,0),c(0,1,0),c(0,0,1))
 init=c(.1,.1,.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

################################## k=2


lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),c(0,0,0,1))
 init=c(.1,.1,.1,.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

################################## k=3

lpmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  -sum(log(d3))
}


 c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0),c(1,0,0,0,0),c(0,1,0,0,0),
c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)
################################## k=4

lpmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  -sum(log(d4))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1)
 out4=constrOptim(init, lpmf4, NULL, ui=u_i, ci=c_i)

################################## k=5

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0),
c(0,1,0,0,0,0,0),c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0),
c(0,0,0,0,1,0,0),c(0,0,0,0,0,1,0),c(0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)

################################## k=6

lpmf6 <- function(par) {
  ww6=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6]+par[7])
  la6=par[8]
  d6 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+
 par[7] * (y == 6) + ww6 * dpois(y,la6))            
  -sum(log(d6))
}


 c_i=c(-1,0,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0),c(0,0,0,1,0,0,0,0),
c(0,0,0,0,1,0,0,0),c(0,0,0,0,0,1,0,0),c(0,0,0,0,0,0,1,0),c(0,0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1,.1)
 out6=constrOptim(init, lpmf6, NULL, ui=u_i, ci=c_i)

#############################################
#############################################

################################## POISSON
fpois=function(par,y) {
  lap=par
  dp <- dpois(y,lap)           
  dp
}

################################## NB
fnb=function(par,y) {
  pnb=par
  dnb <- dnbinom(y,1,pnb)           
  dnb
}

################################## k=0
pmf0 <- function(par,y) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  d0
}


################################## k=1
pmf1 <- function(par,y) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  d1
}



################################## k=2


pmf2 <- function(par,y) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  d2
}


################################## k=3

pmf3 <- function(par,y) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  d3
}

################################## k=4

pmf4 <- function(par,y) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  d4
}
################################## k=5

pmf5 <- function(par,y) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+
+ par[6] * (y == 5) + ww5 * dpois(y,la5))            
  d5
}
################################## k=6

pmf6 <- function(par,y) {
  ww6=(1-par[1]-par[2]-par[3]-par[4]-par[5]-par[6]-par[7])
  la6=par[8]
  d6 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+
+ par[6] * (y == 5) + par[7] * (y == 6) + ww6 * dpois(y,la6))            
  d6
}
#----------------------------------------------------------
z=y
 nn=length(y)

m=length(table(z))
k=7
o=c(table(y)[1:(m-k)],sum(table(y)[(m-(k-1)):(m)]))

##########################################################

#######################################################k=6
ee6=c()
for(i in 0:(m-1)){
ee6[i+1]=mean(pmf6(out6$par,i)*nn)
}
e6=c(ee6[1:(m-k)],sum(ee6[(m-(k-1)):m]))
round(e6,2)

ABE6=sum(abs(o-e6))
round(ABE6,5)

KI6=sum(((o-e6)^2)/e6)
round(KI6,5)


#######################################################k=5
ee5=c()
for(i in 0:(m-1)){
ee5[i+1]=mean(pmf5(out5$par,i)*nn)
}
e5=c(ee5[1:(m-k)],sum(ee5[(m-(k-1)):m]))
round(e5,2)

ABE5=sum(abs(o-e5))
round(ABE5,5)

KI5=sum(((o-e5)^2)/e5)
round(KI5,5)

#######################################################k=4
ee4=c()
for(i in 0:(m-1)){
ee4[i+1]=mean(pmf4(out4$par,i)*nn)
}
e4=c(ee4[1:(m-k)],sum(ee4[(m-(k-1)):m]))

round(e4,2)
ABE4=sum(abs(o-e4))
round(ABE4,4)

KI4=sum(((o-e4)^2)/e4)
round(KI4,4)

#######################################################k=3
ee3=c()
for(i in 0:(m-1)){
ee3[i+1]=mean(pmf3(out3$par,i)*nn)
}
e3=c(ee3[1:(m-k)],sum(ee3[(m-(k-1)):m]))

round(e3,2)

ABE3=sum(abs(o-e3))
round(ABE3,4)

KI3=sum(((o-e3)^2)/e3)
round(KI3,4)


#######################################################k=2
ee2=c()
for(i in 0:(m-1)){
ee2[i+1]=mean(pmf2(out2$par,i)*nn)
}
e2=c(ee2[1:(m-k)],sum(ee2[(m-(k-1)):m]))

round(e2,2)

ABE2=sum(abs(o-e2))
round(ABE2,4)

KI2=sum(((o-e2)^2)/e2)
round(KI2,4)


#######################################################k=1
ee1=c()
for(i in 0:(m-1)){
ee1[i+1]=mean(pmf1(out1$par,i)*nn)
}
e1=c(ee1[1:(m-k)],sum(ee1[(m-(k-1)):m]))

round(e1,2)

ABE1=sum(abs(o-e1))
round(ABE1,4)

KI1=sum(((o-e1)^2)/e1)
round(KI1,4)


#######################################################k=0
ee0=c()
for(i in 0:(m-1)){
ee0[i+1]=mean(pmf0(out0$par,i)*nn)
}
e0=c(ee0[1:(m-k)],sum(ee0[(m-(k-1)):m]))

round(e0,2)

ABE0=sum(abs(o-e0))
round(ABE0,4)

KI0=sum(((o-e0)^2)/e0)
round(KI0,4)


#################################################POISSON
eep=c()
for(i in 0:(m-1)){
eep[i+1]=mean(fpois(outp$minimum,i)*nn)
}
ep=c(eep[1:(m-k)],sum(eep[(m-(k-1)):m]))

round(ep,2)

ABEp=sum(abs(o-ep))
round(ABEp,4)

KIp=sum(((o-ep)^2)/ep)
round(KIp,4)

