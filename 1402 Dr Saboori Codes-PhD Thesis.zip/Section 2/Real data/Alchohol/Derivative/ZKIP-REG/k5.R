rm(list=ls(all=TRUE))
xx <- read.table(file = "D:\\Data\\DeHartSimplified.csv",
header=TRUE , sep= ",", na.strings = " ")
y=xx$numall
y[is.na(y)]<-0
yy=y
  z1=x1=xx$negevent
  z2=x2=xx$nrel
################################MLE

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=exp(par[7]+par[8]*x1+par[9]*x2)
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0,0,0),c(1,0,0,0,0,0,0,0,0),
c(0,1,0,0,0,0,0,0,0),c(0,0,1,0,0,0,0,0,0),c(0,0,0,1,0,0,0,0,0),
c(0,0,0,0,1,0,0,0,0),c(0,0,0,0,0,1,0,0,0))
 init=c(.1,.1,.1,.1,.1,.1,.1,-.1,-.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)

###################################
##########################DRIVATIVE

DD <- function(fname, x, order = 1) {
   if(order < 1) stop("'order' must be >= 1")
   if(order == 1) Deriv(fname,x)
   else DD(Deriv(fname, x), x, order - 1)
}

###############################################K=5
##################################################
lpmf11 <- function(par1,par2,par3,par4,par5,par6,par7,par8,par9) {
   ww11=1-(par1+par2+par3+par4+par5+par6)
  la11=exp(par7+par8*z1+par9*z2)
  d11 <- (par1 * (y == 0) + par2 * (y == 1)+ par3 * (y == 2) +
 par4 * (y == 3) + par5 * (y == 4)+ par6 * (y == 5) + 
 ww11 * (exp(-la11)*((la11)^y)/gamma(y+1)))            
  -sum(log(d11))
}
##############################################w0
x=c("par1")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 0
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2 + par3 + 
        par4 + par5 + par6)) * .e4 * .e5/.e6 + par1 * .e7 + par2 * 
        (y == 1) + par3 * (y == 2) + par4 * (y == 3) + par5 * 
        (y == 4) + par6 * (y == 5))^2))
}
#SE(W0)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
##############################################w1
x=c("par2")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 1
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2 + par3 + 
        par4 + par5 + par6)) * .e4 * .e5/.e6 + par1 * (y == 0) + 
        par2 * .e7 + par3 * (y == 2) + par4 * (y == 3) + par5 * 
        (y == 4) + par6 * (y == 5))^2))
}
#SE(W1)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
##############################################w2
x=c("par3")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 2
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2 + par3 + 
        par4 + par5 + par6)) * .e4 * .e5/.e6 + par1 * (y == 0) + 
        par2 * (y == 1) + par3 * .e7 + par4 * (y == 3) + par5 * 
        (y == 4) + par6 * (y == 5))^2))
}
#SE(w2)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
##############################################w3
x=c("par4")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 3
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2 + par3 + 
        par4 + par5 + par6)) * .e4 * .e5/.e6 + par1 * (y == 0) + 
        par2 * (y == 1) + par3 * (y == 2) + par4 * .e7 + par5 * 
        (y == 4) + par6 * (y == 5))^2))
}
#SE(w3)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
##############################################w4
x=c("par5")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 4
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2 + par3 + 
        par4 + par5 + par6)) * .e4 * .e5/.e6 + par1 * (y == 0) + 
        par2 * (y == 1) + par3 * (y == 2) + par4 * (y == 3) + 
        par5 * .e7 + par6 * (y == 5))^2))
}
#SE(w4)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
##############################################w5
x=c("par6")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 5
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2 + par3 + 
        par4 + par5 + par6)) * .e4 * .e5/.e6 + par1 * (y == 0) + 
        par2 * (y == 1) + par3 * (y == 2) + par4 * (y == 3) + 
        par5 * (y == 4) + par6 * .e7)^2))
}
#SE(w5)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
##############################################b0
x=c("par7")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e2 <- .e1^y
    .e3 <- 1 + y
    .e5 <- 1 - (par1 + par2 + par3 + par4 + par5 + par6)
    .e6 <- exp(-.e1)
    .e8 <- y - 1
    .e9 <- .e5 * .e6
    .e10 <- .e1^.e8
    .e11 <- (.e9 * .e2/gamma(.e3) + par1 * (y == 0) + par2 * 
        (y == 1) + par3 * (y == 2) + par4 * (y == 3) + par5 * 
        (y == 4) + par6 * (y == 5)) * gamma(.e3)
    .e13 <- y * .e10 - .e2
    -sum((((1 - .e1) * .e13 + y * (.e10 * .e8 - .e2))/.e11 - 
        .e9 * .e13 * (y * .e2 - .e1^.e3)/.e11^2) * .e5 * .e6 * 
        .e1)
}
#SE(lambda)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))

##############################################b1
x=c("par8")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e2 <- .e1^y
    .e3 <- 1 + y
    .e5 <- 1 - (par1 + par2 + par3 + par4 + par5 + par6)
    .e6 <- exp(-.e1)
    .e8 <- y - 1
    .e9 <- .e5 * .e6
    .e10 <- .e1^.e8
    .e11 <- (.e9 * .e2/gamma(.e3) + par1 * (y == 0) + par2 * 
        (y == 1) + par3 * (y == 2) + par4 * (y == 3) + par5 * 
        (y == 4) + par6 * (y == 5)) * gamma(.e3)
    .e13 <- y * .e10 - .e2
    -sum(z1^2 * (((1 - .e1) * .e13 + y * (.e10 * .e8 - .e2))/.e11 - 
        .e9 * .e13 * (y * .e2 - .e1^.e3)/.e11^2) * .e5 * .e6 * 
        .e1)
}
#SE(lambda)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))

##############################################b2
x=c("par9")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5, par6, par7, par8, par9) 
{
    .e1 <- exp(par7 + par8 * z1 + par9 * z2)
    .e2 <- .e1^y
    .e3 <- 1 + y
    .e5 <- 1 - (par1 + par2 + par3 + par4 + par5 + par6)
    .e6 <- exp(-.e1)
    .e8 <- y - 1
    .e9 <- .e5 * .e6
    .e10 <- .e1^.e8
    .e11 <- (.e9 * .e2/gamma(.e3) + par1 * (y == 0) + par2 * 
        (y == 1) + par3 * (y == 2) + par4 * (y == 3) + par5 * 
        (y == 4) + par6 * (y == 5)) * gamma(.e3)
    .e13 <- y * .e10 - .e2
    -sum(z2^2 * (((1 - .e1) * .e13 + y * (.e10 * .e8 - .e2))/.e11 - 
        .e9 * .e13 * (y * .e2 - .e1^.e3)/.e11^2) * .e5 * .e6 * 
        .e1)
}
#SE(lambda)
sqrt(1/D2lpmf11(out5$par[1],out5$par[2],out5$par[3],out5$par[4],out5$par[5],
out5$par[6],out5$par[7],out5$par[8],out5$par[9]))
