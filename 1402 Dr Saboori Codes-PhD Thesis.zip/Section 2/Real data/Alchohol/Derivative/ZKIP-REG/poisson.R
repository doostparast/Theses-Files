sqrt(1/D2lpmf11(out0$par[1],out0$par[2],out0$par[3],orm(list=ls(all=TRUE))
library("Deriv")
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx)

  yy=y=xx$illness

  z1=x1=xx$age
  z2=x2=xx$sex
################################################
#############################################MLE
lfpois=function(par) {
  lap=exp(par[1]+par[2]*x1+par[3]*x2)
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 init=c(0,0,.0)
 outp=optim(init, lfpois)
###############################################D

###############################################POISSON
 lfpois=function(par1,par2,par3) {
   lap=exp(par1+par2*z1+par3*z2)
   dp <- (exp(-lap)*((lap)^y)/gamma(y+1) )          
   -sum(log(dp))
  }
#-----------------------------------------------------b0

x=c("par1")#vector of unknown parameters
DD(lfpois,x,2)

D2lfpois=function (par1, par2, par3) 
{
    .e1 <- exp(par1 + par2 * z1 + par3 * z2)
    .e2 <- y - 1
    .e3 <- 1 - y
    .e4 <- .e1^.e2
    .e5 <- .e1^y
    -sum((.e3 * (y * .e4 - .e5)/.e5 + y * .e1^.e3 * (.e1^(y - 
        2) * .e2 - .e4)) * .e1)
}
sqrt(1/D2lfpois(outp$par[1],outp$par[2],outp$par[3]))
#-------------------------------------------------------b1

x=c("par2")#vector of unknown parameters
DD(lfpois,x,2)

D2lfpois=function (par1, par2, par3) 
{
    .e1 <- exp(par1 + par2 * z1 + par3 * z2)
    .e2 <- y - 1
    .e3 <- 1 - y
    .e4 <- .e1^.e2
    .e5 <- .e1^y
    -sum(z1^2 * (.e3 * (y * .e4 - .e5)/.e5 + y * .e1^.e3 * (.e1^(y - 
        2) * .e2 - .e4)) * .e1)
}
sqrt(1/(D2lfpois(outp$par[1],outp$par[2],outp$par[3])))
#----------------------------------------------------------b2

x=c("par3")#vector of unknown parameters
DD(lfpois,x,2)

D2lfpois=function (par1, par2, par3) 
{
    .e1 <- exp(par1 + par2 * z1 + par3 * z2)
    .e2 <- y - 1
    .e3 <- 1 - y
    .e4 <- .e1^.e2
    .e5 <- .e1^y
    -sum(z2^2 * (.e3 * (y * .e4 - .e5)/.e5 + y * .e1^.e3 * (.e1^(y - 
        2) * .e2 - .e4)) * .e1)
}
sqrt(1/(D2lfpois(outp$par[1],outp$par[2],outp$par[3])))