rm(list=ls(all=TRUE))
xx <- read.table(file = "D:\\Data\\DeHartSimplified.csv",
header=TRUE , sep= ",", na.strings = " ")
y=xx$numall
y[is.na(y)]<-0
yy=y
############################MLE
################################## POISSON
lfpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 outp=optimize(lfpois,c(0,100))

################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)
###############################D
DD <- function(fname, x, order = 1) {
   if(order < 1) stop("'order' must be >= 1")
   if(order == 1) Deriv(fname,x)
   else DD(Deriv(fname, x), x, order - 1)
}
###############################################POISSON
 lfpois=function(par) {
   lap=par
   dp <- (exp(-lap)*((lap)^y)/gamma(y+1) )          
   sum(log(dp))
  }

x=c("par")#vector of unknown parameters
DD(lfpois,x,2)

D2lfpois=function(par) 
{
    .e1 <- par^y
    .e2 <- y - 1
    .e3 <- par^.e2
    -sum(y * (par^(y - 2) * .e2 - .e3 * ((.e3 * y - .e1)/.e1 + 
        1))/.e1)
}
sqrt(1/(D2lfpois(outp$minimum)))
###############################################K=0
##################################################
lpmf11 <- function(par1,par2) {
   ww11=1-(par1)
  la11=par2
  d11 <- (par1 * (y == 0) + ww11 * (exp(-la11)*((la11)^y)/gamma(y+1)))            
  -sum(log(d11))
}
##############################################w0
x=c("par1")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2)
{
    .e3 <- exp(-par2)
    .e4 <- gamma(1 + y)
    .e5 <- par2^y
    .e6 <- y == 0
    -sum(-((.e6 - .e5 * .e3/.e4)^2/(par1 * .e6 + .e5 * (1 - par1) * 
        .e3/.e4)^2))
}
#SE(W0)
sqrt(1/D2lpmf11(out0$par[1],out0$par[2]))
##############################################la
x=c("par2")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2)
{
    .e2 <- 1 - par1
    .e4 <- exp(-par2)
    .e6 <- par2^y
    .e7 <- y - 1
    .e8 <- gamma(1 + y) * (par1 * (y == 0) + .e6 * .e2 * .e4/gamma(1 + 
        y))
    .e9 <- par2^.e7
    -sum(((.e6 + y * (par2^(y - 2) * .e7 - 2 * .e9))/.e8 - .e2 * 
        .e4 * (.e9 * y - .e6)^2/.e8^2) * .e2 * .e4)
}
#SE(lambda)
sqrt(1/D2lpmf11(out0$par[1],out0$par[2]))


