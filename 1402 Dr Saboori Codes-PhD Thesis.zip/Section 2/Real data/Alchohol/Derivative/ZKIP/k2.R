rm(list=ls(all=TRUE))
xx <- read.table(file = "D:\\Data\\DeHartSimplified.csv",
header=TRUE , sep= ",", na.strings = " ")
y=xx$numall
y[is.na(y)]<-0
yy=y
############################MLE

lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),c(0,0,0,1))
 init=c(.1,.1,.1,.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

############################################### D
DD <- function(fname, x, order = 1) {
   if(order < 1) stop("'order' must be >= 1")
   if(order == 1) Deriv(fname,x)
   else DD(Deriv(fname, x), x, order - 1)
}
##################################################
lpmf11 <- function(par1,par2,par3,par4) {
   ww11=1-(par1+par2+par3)
  la11=par4
  d11 <- (par1 * (y == 0) + par2 * (y == 1)+ par3 * (y == 2) +
 ww11 * (exp(-la11)*((la11)^y)/gamma(y+1)))            
  -sum(log(d11))
}
##############################################w0
x=c("par1")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4) 
{
    .e3 <- exp(-par4)
    .e4 <- gamma(1 + y)
    .e5 <- par4^y
    .e6 <- y == 0
    -sum(-((.e6 - .e5 * .e3/.e4)^2/(par1 * .e6 + par2 * (y == 
        1) + par3 * (y == 2) + .e5 * (1 - (par1 + par2 + par3)) * 
        .e3/.e4)^2))
}
#SE(W0)
sqrt(1/D2lpmf11(out2$par[1],out2$par[2],out2$par[3],out2$par[4]))
##############################################w1
x=c("par2")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4) 
{
    .e3 <- exp(-par4)
    .e4 <- gamma(1 + y)
    .e5 <- par4^y
    .e6 <- y == 1
    -sum(-((.e6 - .e5 * .e3/.e4)^2/(par1 * (y == 0) + par2 * 
        .e6 + par3 * (y == 2) + .e5 * (1 - (par1 + par2 + par3)) * 
        .e3/.e4)^2))
}
#SE(W1)
sqrt(1/D2lpmf11(out2$par[1],out2$par[2],out2$par[3],out2$par[4]))

##############################################w3
x=c("par3")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4) 
{
    .e3 <- exp(-par4)
    .e4 <- gamma(1 + y)
    .e5 <- par4^y
    .e6 <- y == 2
    -sum(-((.e6 - .e5 * .e3/.e4)^2/(par1 * (y == 0) + par2 * 
        (y == 1) + par3 * .e6 + .e5 * (1 - (par1 + par2 + par3)) * 
        .e3/.e4)^2))
}
#SE(w2)
sqrt(1/D2lpmf11(out2$par[1],out2$par[2],out2$par[3],out2$par[4]))
##############################################lambda
x=c("par4")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4) 
{
    .e2 <- 1 - (par1 + par2 + par3)
    .e4 <- exp(-par4)
    .e6 <- par4^y
    .e7 <- y - 1
    .e8 <- gamma(1 + y) * (par1 * (y == 0) + par2 * (y == 1) + 
        par3 * (y == 2) + .e6 * .e2 * .e4/gamma(1 + y))
    .e9 <- par4^.e7
    -sum(((.e6 + y * (par4^(y - 2) * .e7 - 2 * .e9))/.e8 - .e2 * 
        .e4 * (.e9 * y - .e6)^2/.e8^2) * .e2 * .e4)
}
#SE(lambda)
sqrt(1/D2lpmf11(out2$par[1],out2$par[2],out2$par[3],out2$par[4]))

