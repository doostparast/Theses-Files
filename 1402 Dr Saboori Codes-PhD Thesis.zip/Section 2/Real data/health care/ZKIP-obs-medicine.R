rm(list=ls(all=TRUE))
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx)

  y=xx$medicine
  yy=xx$medicine

##############################################
################################### ESTIMATION

################################## POISSON
lfpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  -sum(log(dp))
}

 init=c(.1)
 outp=optim(init, lfpois)
################################## NB
lfnb=function(par) {
  pnb=par
  dnb <- dnbinom(y,1,pnb)           
  -sum(log(dnb))
}

 init=c(.1)
 outnb=optim(init, lfnb)
################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)

################################## k=1
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,0),c(1,0,0),c(0,1,0),c(0,0,1))
 init=c(.1,.1,.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

################################## k=2


lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),c(0,0,0,1))
 init=c(.1,.1,.1,.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

################################## k=3

lpmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  -sum(log(d3))
}


 c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0),c(1,0,0,0,0),c(0,1,0,0,0),
c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)
################################## k=4

lpmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  -sum(log(d4))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1)
 out4=constrOptim(init, lpmf4, NULL, ui=u_i, ci=c_i)
################################## k=5

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0),
c(0,1,0,0,0,0,0),c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0),
c(0,0,0,0,1,0,0),c(0,0,0,0,0,1,0),c(0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)


#############################################
#############################################
n=length(yy)
nn=(length(table(yy)))
m=7

obs=c(table(yy)[1:(m)],sum(table(yy)[(m+1):nn]))
y=0:(nn-1)


################################## POISSON
fpois=function(par) {
  lap=par
  dp <- dpois(y,lap)           
  dp
}

################################## NB
fnb=function(par) {
  pnb=par
  dnb <- dnbinom(y,1,pnb)           
  dnb
}

################################## k=0
pmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  d0
}


################################## k=1
pmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  d1
}



################################## k=2


pmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  d2
}


################################## k=3

pmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  d3
}

################################## k=4

pmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  d4
}
################################## k=5

pmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+
+ par[6] * (y == 5) + ww5 * dpois(y,la5))            
  d5
}
#####################################Expectaion of observation
round(fpois(outp$par)*n,2)
round(sum((fpois(outp$par)*n)[(m+1):nn]),2)

round(pmf0(out0$par)*n,2)
round(sum((pmf0(out0$par)*n)[(m+1):nn]),2)

round(pmf1(out1$par)*n,2)
round(sum((pmf1(out1$par)*n)[(m+1):nn]),2)

round(pmf2(out2$par)*n,2)
round(sum((pmf2(out2$par)*n)[(m+1):nn]),2)

round(pmf3(out3$par)*n,2)
round(sum((pmf3(out3$par)*n)[(m+1):nn]),2)

round(pmf4(out4$par)*n,2)
round(sum((pmf4(out4$par)*n)[(m+1):nn]),2)

round(pmf5(out5$par)*n,2)
round(sum((pmf5(out5$par)*n)[(m+1):nn]),2)

##########################################poisson
eep=(fpois(outp$par)*n)
ep=c(eep[1:(m)],sum(eep[(m+1):nn]))
ABEp=sum(abs(obs-ep))
kip=sum(((ep-obs)^2)/ep)
round(ABEp,2)
round(kip,2)
##########################################k=0
ee0=(pmf0(out0$par)*n)
e0=c(ee0[1:m],sum(ee0[(m+1):nn]))
ABE0=sum(abs(obs-e0))
ki0=sum(((e0-obs)^2)/e0)
round(ABE0,2)
round(ki0,2)
##########################################k=1
ee1=(pmf1(out1$par)*n)
e1=c(ee1[1:m],sum(ee1[(m+1):nn]))
ABE1=sum(abs(obs-e1))
ki1=sum(((e1-obs)^2)/e1)
round(ABE1,2)
round(ki1,2)
##########################################k=2
ee2=(pmf2(out2$par)*n)
e2=c(ee2[1:m],sum(ee2[(m+1):nn]))
ABE2=sum(abs(obs-e2))
ki2=sum(((e2-obs)^2)/e2)
round(ABE2,2)
round(ki2,2)
##########################################k=3
ee3=(pmf3(out3$par)*n)
e3=c(ee3[1:m],sum(ee3[(m+1):nn]))
ABE3=sum(abs(obs-e3))
ki3=sum(((e3-obs)^2)/e3)
round(ABE3,2)
round(ki3,2)
##########################################k=4
ee4=(pmf4(out4$par)*n)
e4=c(ee4[1:m],sum(ee4[(m+1):nn]))
ABE4=sum(abs(obs-e4))
ki4=sum(((e4-obs)^2)/e4)
round(ABE4,2)
round(ki4,2)
##########################################k=5
ee5=(pmf5(out5$par)*n)
e5=c(ee5[1:m],sum(ee5[(m+1):nn]))
ABE5=sum(abs(obs-e5))
ki5=sum(((e5-obs)^2)/e5)
round(ABE5,2)
round(ki5,2)
