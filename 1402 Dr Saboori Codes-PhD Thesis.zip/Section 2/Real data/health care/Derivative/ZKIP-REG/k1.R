rm(list=ls(all=TRUE))
library("Deriv")
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx)

  yy=y=xx$illness

  z1=x1=xx$age
  z2=x2=xx$sex
################################################
#############################################MLE
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=exp(par[3]+par[4]*x1+par[5]*x2)
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,-1,0,0,0),c(1,0,0,0,0),c(0,1,0,0,0))
 init=c(.2,.2,.1,-.1,-.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)
###############################################D
DD <- function(fname, x, order = 1) {
   if(order < 1) stop("'order' must be >= 1")
   if(order == 1) Deriv(fname,x)
   else DD(Deriv(fname, x), x, order - 1)
}

###############################################K=
##################################################
lpmf11 <- function(par1,par2,par3,par4,par5) {
   ww11=1-(par1+par2)
  la11=exp(par3+par4*z1+par5*z2)
  d11 <- (par1 * (y == 0) + par2 * (y == 1) 
+ ww11 * (exp(-la11)*((la11)^y)/gamma(y+1)))            
  -sum(log(d11))
}
##############################################w0
x=c("par1")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5) 
{
    .e1 <- exp(par3 + par4 * z1 + par5 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 0
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2)) * .e4 * 
        .e5/.e6 + par1 * .e7 + par2 * (y == 1))^2))
}
#SE(W0)
sqrt(1/D2lpmf11(out1$par[1],out1$par[2],out1$par[3],out1$par[4],out1$par[5]))
##############################################w1
x=c("par2")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5) 
{
    .e1 <- exp(par3 + par4 * z1 + par5 * z2)
    .e4 <- exp(-.e1)
    .e5 <- .e1^y
    .e6 <- gamma(1 + y)
    .e7 <- y == 1
    -sum(-((.e7 - .e4 * .e5/.e6)^2/((1 - (par1 + par2)) * .e4 * 
        .e5/.e6 + par1 * (y == 0) + par2 * .e7)^2))
}
#SE(W1)
sqrt(1/D2lpmf11(out1$par[1],out1$par[2],out1$par[3],out1$par[4],out1$par[5]))
##############################################b0
x=c("par3")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5) 
{
    .e1 <- exp(par3 + par4 * z1 + par5 * z2)
    .e2 <- .e1^y
    .e3 <- 1 + y
    .e5 <- 1 - (par1 + par2)
    .e6 <- exp(-.e1)
    .e8 <- y - 1
    .e9 <- .e5 * .e6
    .e10 <- .e1^.e8
    .e11 <- (.e9 * .e2/gamma(.e3) + par1 * (y == 0) + par2 * 
        (y == 1)) * gamma(.e3)
    .e13 <- y * .e10 - .e2
    -sum((((1 - .e1) * .e13 + y * (.e10 * .e8 - .e2))/.e11 - 
        .e9 * .e13 * (y * .e2 - .e1^.e3)/.e11^2) * .e5 * .e6 * 
        .e1)
}
#SE(lambda)
sqrt(1/D2lpmf11(out1$par[1],out1$par[2],out1$par[3],out1$par[4],out1$par[5]))
##############################################b1
x=c("par4")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5) 
{
    .e1 <- exp(par3 + par4 * z1 + par5 * z2)
    .e2 <- .e1^y
    .e3 <- 1 + y
    .e5 <- 1 - (par1 + par2)
    .e6 <- exp(-.e1)
    .e8 <- y - 1
    .e9 <- .e5 * .e6
    .e10 <- .e1^.e8
    .e11 <- (.e9 * .e2/gamma(.e3) + par1 * (y == 0) + par2 * 
        (y == 1)) * gamma(.e3)
    .e13 <- y * .e10 - .e2
    -sum(z1^2 * (((1 - .e1) * .e13 + y * (.e10 * .e8 - .e2))/.e11 - 
        .e9 * .e13 * (y * .e2 - .e1^.e3)/.e11^2) * .e5 * .e6 * 
        .e1)
}
#SE(lambda)
sqrt(1/D2lpmf11(out1$par[1],out1$par[2],out1$par[3],out1$par[4],out1$par[5]))
##############################################b2
x=c("par5")#vector of unknown parameters
DD(lpmf11,x,2)

D2lpmf11=function (par1, par2, par3, par4, par5) 
{
    .e1 <- exp(par3 + par4 * z1 + par5 * z2)
    .e2 <- .e1^y
    .e3 <- 1 + y
    .e5 <- 1 - (par1 + par2)
    .e6 <- exp(-.e1)
    .e8 <- y - 1
    .e9 <- .e5 * .e6
    .e10 <- .e1^.e8
    .e11 <- (.e9 * .e2/gamma(.e3) + par1 * (y == 0) + par2 * 
        (y == 1)) * gamma(.e3)
    .e13 <- y * .e10 - .e2
    -sum(z2^2 * (((1 - .e1) * .e13 + y * (.e10 * .e8 - .e2))/.e11 - 
        .e9 * .e13 * (y * .e2 - .e1^.e3)/.e11^2) * .e5 * .e6 * 
        .e1)
}
#SE(lambda)
sqrt(1/D2lpmf11(out1$par[1],out1$par[2],out1$par[3],out1$par[4],out1$par[5]))

