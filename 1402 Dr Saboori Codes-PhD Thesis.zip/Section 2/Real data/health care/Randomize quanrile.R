rm(list=ls(all=TRUE))
x=load(file = "d://Data/ex3.rda")
xx=ex3.health
head(xx)

  yy=y=xx$medicine
  n=length(y)
##############################################
################################### ESTIMATION


################################## k=0
lpmf0 <- function(par) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  -sum(log(d0))
}


 c_i=c(-1,0,0)
 u_i=rbind(c(-1,0),c(1,0),c(0,1))
 init=c(.1,.1)
 out0=constrOptim(init, lpmf0, NULL, ui=u_i, ci=c_i)

################################## k=1
lpmf1 <- function(par) {
  ww1=1-(par[1]+par[2])
  la1=par[3]
  d1 <- (par[1] * (y == 0) + par[2] * (y == 1)+  ww1 * dpois(y,la1))            
  -sum(log(d1))
}


 c_i=c(-1,0,0,0)
 u_i=rbind(c(-1,-1,0),c(1,0,0),c(0,1,0),c(0,0,1))
 init=c(.1,.1,.1)
 out1=constrOptim(init, lpmf1, NULL, ui=u_i, ci=c_i)

################################## k=2


lpmf2 <- function(par) {
  ww2=1-(par[1]+par[2]+par[3])
  la2=par[4]
  d2 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  -sum(log(d2))
}


 c_i=c(-1,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,0),c(1,0,0,0),c(0,1,0,0),c(0,0,1,0),c(0,0,0,1))
 init=c(.1,.1,.1,.1)
 out2=constrOptim(init, lpmf2, NULL, ui=u_i, ci=c_i)

################################## k=3

lpmf3 <- function(par) {
  ww3=1-(par[1]+par[2]+par[3]+par[4])
  la3=par[5]
  d3 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3)+ ww3 * dpois(y,la3))            
  -sum(log(d3))
}


 c_i=c(-1,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,0),c(1,0,0,0,0),c(0,1,0,0,0),
c(0,0,1,0,0),c(0,0,0,1,0),c(0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1)
 out3=constrOptim(init, lpmf3, NULL, ui=u_i, ci=c_i)
################################## k=4

lpmf4 <- function(par) {
  ww4=1-(par[1]+par[2]+par[3]+par[4]+par[5])
  la4=par[6]
  d4 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ ww4 * dpois(y,la4))            
  -sum(log(d4))
}


 c_i=c(-1,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0),c(0,1,0,0,0,0),
c(0,0,1,0,0,0),c(0,0,0,1,0,0),c(0,0,0,0,1,0),c(0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1)
 out4=constrOptim(init, lpmf4, NULL, ui=u_i, ci=c_i)
################################## k=5

lpmf5 <- function(par) {
  ww5=1-(par[1]+par[2]+par[3]+par[4]+par[5]+par[6])
  la5=par[7]
  d5 <- (par[1] * (y == 0) + par[2] * (y == 1)+ par[3] * (y == 2) +
 par[4] * (y == 3) + par[5] * (y == 4)+ par[6] * (y == 5)+ ww5 * dpois(y,la5))            
  -sum(log(d5))
}


 c_i=c(-1,0,0,0,0,0,0,0)
 u_i=rbind(c(-1,-1,-1,-1,-1,-1,0),c(1,0,0,0,0,0,0),
c(0,1,0,0,0,0,0),c(0,0,1,0,0,0,0),c(0,0,0,1,0,0,0),
c(0,0,0,0,1,0,0),c(0,0,0,0,0,1,0),c(0,0,0,0,0,0,1))
 init=c(.1,.1,.1,.1,.1,.1,.1)
 out5=constrOptim(init, lpmf5, NULL, ui=u_i, ci=c_i)
#########################################################################
############################################Randomitze Quantile Residuals

################################## POISSON
lap=mean(y)

rqp=ppois(y-1,lap) + dpois(y,lap) * runif(n)

################################## k=0
par=out0$par
pmf0 <- function(y) {
  ww0=(1-par[1])
  la0=par[2]
  d0 <- (par[1] * (y == 0) +  ww0 * dpois(y,la0))            
  d0
}
CDF0=function(y){
 n=length(y)
 cdf=rep(0,n)
 for(i in 1:n)
  {
   cdf[i]=0
   if(y[i]<0) cdf[i]=0
   else if(y[i]>-1){
     for(j in 0:y[i]) cdf[i]=cdf[i]+pmf0(j)
    }
   }
 cdf
}
rq0=CDF0(y-1) + pmf0(y) * runif(n)


################################## k=1
par1=out1$par
pmf1 <- function(y) {
  ww1=1-(par1[1]+par1[2])
  la1=par1[3]
  d1 <- (par1[1] * (y == 0) + par1[2] * (y == 1)+  ww1 * dpois(y,la1))            
  d1
}

CDF1=function(y){
 n=length(y)
 cdf1=rep(0,n)
 for(i in 1:n)
  {
   cdf1[i]=0
   if(y[i]<0) cdf1[i]=0
   else if(y[i]>-1){
     for(j in 0:y[i]) cdf1[i]=cdf1[i]+pmf1(j)
    }
   }
 cdf1
}

rq1=CDF1(y-1) + pmf1(y) * runif(n)


################################## k=2

par2=out2$par
pmf2 <- function(y) {
  ww2=1-(par2[1]+par2[2]+par2[3])
  la2=par2[4]
  d2 <- (par2[1] * (y == 0) + par2[2] * (y == 1)+ par2[3] * (y == 2) +
  ww2 * dpois(y,la2))            
  d2
}

CDF2=function(y){
 n=length(y)
 cdf2=rep(0,n)
 for(i in 1:n)
  {
   cdf2[i]=0
   if(y[i]<0) cdf2[i]=0
   else if(y[i]>-1){
     for(j in 0:y[i]) cdf2[i]=cdf2[i]+pmf2(j)
    }
   }
 cdf2
}

rq2=CDF2(y-1) + pmf2(y) * runif(n)

################################## k=3

par3=out3$par
pmf3 <- function(y) {
  ww3=1-(par3[1]+par3[2]+par3[3]+par3[4])
  la3=par3[5]
  d3 <- (par3[1] * (y == 0) + par3[2] * (y == 1)+ par3[3] * (y == 2) +
 par3[4] * (y == 3)+ ww3 * dpois(y,la3))            
  d3
}

CDF3=function(y){
 n=length(y)
 cdf3=rep(0,n)
 for(i in 1:n)
  {
   cdf3[i]=0
   if(y[i]<0) cdf3[i]=0
   else if(y[i]>-1){
     for(j in 0:y[i]) cdf3[i]=cdf3[i]+pmf3(j)
    }
   }
 cdf3
}

rq3=CDF3(y-1) + pmf3(y) * runif(n)

################################## k=4

par4=out4$par
pmf4 <- function(y) {
  ww4=1-(par4[1]+par4[2]+par4[3]+par4[4]+par4[5])
  la4=par4[6]
  d4 <- (par4[1] * (y == 0) + par4[2] * (y == 1)+ par4[3] * (y == 2) +
 par4[4] * (y == 3) + par4[5] * (y == 4)+ ww4 * dpois(y,la4))            
  d4
}

CDF4=function(y){
 n=length(y)
 cdf4=rep(0,n)
 for(i in 1:n)
  {
   cdf4[i]=0
   if(y[i]<0) cdf4[i]=0
   else if(y[i]>-1){
     for(j in 0:y[i]) cdf4[i]=cdf4[i]+pmf4(j)
    }
   }
 cdf4
}

rq4=CDF4(y-1) + pmf4(y) * runif(n)

################################## k=5

par5=out5$par
pmf5 <- function(y) {
  ww5=1-(par5[1]+par5[2]+par5[3]+par5[4]+par5[5]+par5[6])
  la5=par5[7]
  d5 <- (par5[1] * (y == 0) + par5[2] * (y == 1)+ par5[3] * (y == 2) +
 par5[4] * (y == 3) + par5[5] * (y == 4)+
 par5[6] * (y == 5)+ ww5 * dpois(y,la5))            
  d5
}

CDF5=function(y){
 n=length(y)
 cdf5=rep(0,n)
 for(i in 1:n)
  {
   cdf5[i]=0
   if(y[i]<0) cdf5[i]=0
   else if(y[i]>-1){
     for(j in 0:y[i]) cdf5[i]=cdf5[i]+pmf5(j)
    }
   }
 cdf5
}

rq5=CDF5(y-1) + pmf5(y) * runif(n)

####################Randomized Quantile
plot(qnorm(rqp),xlab="Observation Number",ylab="Randomized Quantile")
plot(qnorm(rq0),xlab="Observation Number",ylab="Randomized Quantile")
plot(qnorm(rq1),xlab="Observation Number",ylab="Randomized Quantile")
plot(qnorm(rq2),xlab="Observation Number",ylab="Randomized Quantile")
plot(qnorm(rq3),xlab="Observation Number",ylab="Randomized Quantile")
plot(qnorm(rq4),xlab="Observation Number",ylab="Randomized Quantile")
plot(qnorm(rq5),xlab="Observation Number",ylab="Randomized Quantile")

hist(rqp,xlab="p-value",main="Randomized Quantile")
hist(rq0,xlab="p-value",main="Randomized Quantile")
hist(rq1,xlab="p-value",main="Randomized Quantile")
hist(rq2,xlab="p-value",main="Randomized Quantile")
hist(rq3,xlab="p-value",main="Randomized Quantile")
hist(rq4,xlab="p-value",main="Randomized Quantile")
hist(rq5,xlab="p-value",main="Randomized Quantile")

#######################################
################################QQ-plot

qqnorm(qnorm(rqp),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rqp),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq0),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq0),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq1),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq1),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq2),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq2),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq3),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq3),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq4),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq4),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")

qqnorm(qnorm(rq5),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
qqline(qnorm(rq5),main="Randomized Quantile",ylab="Sample Quantiles",xlab="Theoretical Quantiles")
