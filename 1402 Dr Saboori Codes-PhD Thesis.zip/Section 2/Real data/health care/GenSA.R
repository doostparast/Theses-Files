rm(list=ls(all=TRUE))
library(GenSA)
#######################################PMF k=2
lpmf <- function(x, par) {
  ww=1-(par[1]+par[2]+par[3]++par[4])
  d <- par[1] * (x == 0) +par[2] * (x == 1) + par[3] * (x == 2) +
  par[4] * (x == 3) +ww * dpois(x, par[5])              
  -sum(log(d))
}

##################################simulatio data
rzkip <- function(n, la, p) {
  out=rep(0,n)
  for(i in 1:n)
   {
    ran=sample(c(0,1,2,3,4), size=1, prob=p)
    if(ran==0) out[i]=0
    else if(ran==1) out[i]=1
    else if(ran==2) out[i]=2
    else if(ran==3) out[i]=3
    else if(ran==4) out[i]=rpois(1,la)
   }
return(out)
}
##############################################
################################### SIMILATION
m=10
fout=matrix(0,m,6)
for(i in 1:m)
{
 nn=1000
 la=.1
 p=c(.2,.2,.2,.2,.2)
 xx=rzkip (nn, la, p)
 plot(table(xx))
 #lpmf(xx,c(0.4,0.2,0.1,3))
 ########################################MLE
 # starting model parameters
 par = c(.2,.2,.2,.2,1)

 # limits to the parameter space
 lower <- c(0,0,0,0,0)
 upper <- c(.3,.3,.3,.3,20)

 # optimize the model parameters
 out = GenSA(
  par = par,
  fn = lpmf,
  x = xx,
  lower = lower,
  upper = upper,
  control=list(temperature = 4000)
 )
 #out[c("value","par","counts")]
fout[i,]=c(out$par,out$value)
print(i)
}
mean(c(fout[,1]))
mean(c(fout[,2]))
mean(c(fout[,3]))
mean(c(fout[,4]))
mean(c(fout[,5]))
mean(c(fout[,6]))

sqrt(var(c(fout[,1])))
sqrt(var(c(fout[,2])))
sqrt(var(c(fout[,3])))
sqrt(var(c(fout[,4])))
sqrt(var(c(fout[,5])))


