rm(list=ls(all=TRUE))
library(GenSA)
#######################################PMF k=2
lpmf <- function(x, par) {
  ww=1-(par[1]+par[2]+par[3])
  d <- par[1] * (x == 0) +par[2] * (x == 1) + par[3] * (x == 2) + ww * dpois(x, par[4])              
  -sum(log(d))
}

##################################simulatio data

 xx=c(rep(0,1884),rep(1,1417),rep(2,1362),rep(3,1536),rep(4,1115)
,rep(),rep(),rep(),rep())
 table(xx)
 lpmf(xx,c(0.4,0.2,0.1,3))
 ########################################MLE
 # starting model parameters
 par = c(.2,.2,.2,1)

 # limits to the parameter space
 lower <- c(0,0,0,0)
 upper <- c(.5,.3,.2,10)

 # optimize the model parameters
 out = GenSA(
  par = par,
  fn = lpmf,
  x = xx,
  lower = lower,
  upper = upper,
  control=list(temperature = 4000)
 )
 out[c("value","par","counts")]